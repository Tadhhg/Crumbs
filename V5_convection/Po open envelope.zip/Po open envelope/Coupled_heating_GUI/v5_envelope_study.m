function T = v5_envelope_study(varargin)
%V5_ENVELOPE_STUDY  The power-envelope test plan in one call: for each set of
%   conditions, the best surface sparing (optimal envelope vs constant power),
%   the optimal envelope at a fixed protected layer, and a PI controller.
%
%   T = v5_envelope_study()                      the full plan (~20-30 min, dh 0.5 mm)
%   T = v5_envelope_study('quick', true)         dh 1 mm, a few minutes: check it runs
%   T = v5_envelope_study('cases', C)            your own list (see makeCases below)
%   T = v5_envelope_study('only', 'T_b')         only the sweeps whose name contains 'T_b'
%
%   Every case writes one row to envelope_study.csv (in 'outdir', default ./v5_envelope)
%   and, with 'plot' true (default), a PNG of the two envelopes and the layer temperature.
%
%   Columns (per case): the condition that was changed and its value, then
%     s_max_opt_mm   thickest layer kept < T_protect while the lesion reaches
%                    lesion_depth, optimal envelope (grid rows: 0.5 mm steps at dh 0.5)
%     s_max_cw_mm    the same with the best constant power
%     spared_opt_mm  interpolated never-above-T_protect depth for the optimal run
%     lesion_opt_mm / lesion_cw_mm   lesion depth with the top s_fix mm protected
%     onset_opt_s / onset_cw_s       time the lesion first appears (s)
%     P_mean_opt_W / P_mean_cw_W, P_boost_W (first-frame power), energy_opt_J
%     pid_lesion_mm, pid_overshoot_K  auto-tuned PI on an ideal layer sensor
%   Baseline: photo preset (bench: 12 mm, 1.1 mm, 25 degC water) with P_set = 100 W
%   maximum and t_on = 360 s; protect 45 degC; lesion 50 degC reaching 3 mm; s_fix 1 mm.

o = struct('quick', false, 'cases', [], 'only', '', 'outdir', fullfile(pwd, 'v5_envelope'), ...
           'plot', true, 'lesion_depth', 3, 's_fix', 1, 'pid_T_set_margin', 0.05);
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end
if ~exist(o.outdir, 'dir'), mkdir(o.outdir); end
C = o.cases;  if isempty(C), C = makeCases(); end
if ~isempty(o.only), C = C(~cellfun(@isempty, strfind({C.sweep}, o.only))); end %#ok<STRCLFH>

T = [];
file = fullfile(o.outdir, 'envelope_study.csv');
for k = 1:numel(C)
    c = C(k);
    P = v5_defaults(c.preset);
    P.P_set = 100;  P.t_on = 360;
    if o.quick, P.dh = 1e-3; end
    f = fieldnames(c.set);
    for i = 1:numel(f), P.(f{i}) = c.set.(f{i}); end
    Tp = getf(c, 'T_protect', 45);  Tl = getf(c, 'T_lesion', 50);
    Ld = getf(c, 'lesion_depth', o.lesion_depth);  sf = getf(c, 's_fix', o.s_fix);
    t0 = tic;
    R = v5_solve(P);
    MS  = v5_max_sparing(R, P, 'lesion_depth', Ld, 'T_protect', Tp, 'T_lesion', Tl);
    Out = v5_optimise_envelope(R, P, 's_protect', sf, 'T_protect', Tp, 'T_lesion', Tl, 'verbose', false);
    K   = v5_pid(R, P, 's_protect', sf, 'T_protect', Tp, 'T_lesion', Tl, 'T_set', Tp - o.pid_T_set_margin);

    row = struct();
    row.sweep = c.sweep;  row.value = c.value;  row.preset = c.preset;
    row.P_max_W = P.P_set;  row.t_on_s = P.t_on;  row.T_b_C = P.T_b;  row.T_0_C = P.T_0;
    row.h_s = P.h_s;  row.flow_Lmin = P.flow;  row.d_mm = P.d*1e3;  row.L_mm = P.L*1e3;
    row.P_dropoff = P.P_dropoff;  row.dh_mm = P.dh*1e3;
    row.T_protect_C = Tp;  row.T_lesion_C = Tl;  row.lesion_depth_mm = Ld;  row.s_fix_mm = sf;
    row.s_max_opt_mm = MS.s_max;  row.s_max_cw_mm = MS.cw_s_max;  row.spared_opt_mm = MS.spared;
    row.lesion_opt_mm = Out.track.lesion;  row.lesion_cw_mm = Out.cw.lesion;
    row.onset_opt_s = onset(Out.track.M);  row.onset_cw_s = onset(Out.cw.M);
    row.P_mean_opt_W = Out.track.P_mean;  row.P_mean_cw_W = Out.cw.P_mean;
    row.P_boost_W = P.P_set*Out.track.a(1);  row.energy_opt_J = Out.track.energy;
    row.pid_lesion_mm = K.lesion;  row.pid_overshoot_K = K.overshoot;
    row.pid_Kp = K.gains(1);  row.pid_Ki = K.gains(2);
    row.runtime_s = toc(t0);
    if o.plot, drawCase(R, P, Out, K, c, sf, Tp, o.outdir, k); end
    writeRow(file, row);
    T = [T row]; %#ok<AGROW>
    fprintf('[%d/%d] %s = %s: best sparing %.2f mm (optimal) vs %.2f (CW); at %.1f mm: lesion %.2f vs %.2f mm, onset %.0f vs %.0f s; PI overshoot %+.2f K  (%.0f s)\n', ...
            k, numel(C), c.sweep, num2str(c.value), MS.s_max, MS.cw_s_max, sf, row.lesion_opt_mm, row.lesion_cw_mm, ...
            row.onset_opt_s, row.onset_cw_s, row.pid_overshoot_K, row.runtime_s);
end
end

% =========================================================================
function C = makeCases()
% one-at-a-time around the baseline.  Edit freely: each case is
% struct('sweep', name, 'value', v, 'preset', 'photo'|'table', 'set', struct(...))
% and may also carry T_protect, T_lesion, lesion_depth, s_fix.
C = struct('sweep', {}, 'value', {}, 'preset', {}, 'set', {}, 'T_protect', {}, 'T_lesion', {}, 'lesion_depth', {}, 's_fix', {});
add('baseline', 0, struct());
for v = [5 15 25 37],        add('T_b water degC', v, struct('T_b', v)); end          % gel starts at 25 (photo)
for v = [1400 5000 Inf],     add('h_s W/m2K', v, struct('h_s', v)); end
for v = [1 5 10],            add('flow L/min', v, struct('flow', v)); end
for v = [0.8 1.1 1.6 2.0],   add('d mm (wire height)', v, struct('d', v*1e-3)); end
for v = [60 100 150],        add('P_max W', v, struct('P_set', v)); end
for v = [120 240 360 600],   add('t_on s', v, struct('t_on', v, 't_end', max(600, v + 120))); end
for v = [0.6 0.7 0.8],       add('P_dropoff', v, struct('P_dropoff', v)); end
for v = [43 45 48],          C(end+1) = mk('T_protect degC', v, struct()); C(end).T_protect = v; end
for v = [2 3 5],             C(end+1) = mk('lesion depth mm', v, struct()); C(end).lesion_depth = v; end
for v = [50 55],             C(end+1) = mk('T_lesion degC', v, struct()); C(end).T_lesion = v; end
% the team's setup-table antenna (27 mm, 2 mm, 37 degC water and gel) for comparison
for v = [37 25 15],          C(end+1) = mk('table preset T_b', v, struct('T_b', v, 'T_0', 37, 'T_room', 37)); C(end).preset = 'table'; end
    function add(s, v, st), C(end+1) = mk(s, v, st); end
end

function c = mk(s, v, st)
c = struct('sweep', s, 'value', v, 'preset', 'photo', 'set', st, 'T_protect', [], 'T_lesion', [], 'lesion_depth', [], 's_fix', []);
end

function v = getf(c, f, d)
if isfield(c, f) && ~isempty(c.(f)), v = c.(f); else, v = d; end
end

function t = onset(M)
k = find(M.lesmax_depth > 0, 1);
if isempty(k), t = NaN; else, t = M.t(k); end
end

function drawCase(R, P, Out, K, c, sf, Tp, outdir, k)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 1100 380]);
t = R.t(1:end-1);
ax = subplot(1, 2, 1);  hold(ax, 'on');  grid(ax, 'on');
stairs(ax, t, P.P_set*Out.cw.a, 'LineWidth', 1.6);
stairs(ax, t, P.P_set*Out.track.a, 'LineWidth', 1.6);
stairs(ax, t, P.P_set*K.a, ':', 'LineWidth', 1.4);
xlabel(ax, 'time (s)');  ylabel(ax, 'generator power (W)');  xlim(ax, [0 P.t_on + 30]);
legend(ax, {'best constant power', 'optimal (boost, then hold)', 'PI controller'}, 'Location', 'northeast');
title(ax, sprintf('%s = %s', c.sweep, num2str(c.value)));
ax2 = subplot(1, 2, 2);  hold(ax2, 'on');  grid(ax2, 'on');
plot(ax2, R.t, Out.cw.M.lesmax_depth, 'LineWidth', 1.6);
plot(ax2, R.t, Out.track.M.lesmax_depth, 'LineWidth', 1.6);
plot(ax2, R.t, K.M.lesmax_depth, ':', 'LineWidth', 1.4);
xlabel(ax2, 'time (s)');  ylabel(ax2, 'lesion depth (mm)');
title(ax2, sprintf('top %.1f mm kept below %.0f degC', sf, Tp));
print(fig, fullfile(outdir, sprintf('case_%02d.png', k)), '-dpng', '-r120');
close(fig);
end

function writeRow(file, row)
f = fieldnames(row);  hdr = strjoin(f.', ',');
new = ~exist(file, 'file');
if ~new
    fid = fopen(file, 'r');  h = fgetl(fid);  fclose(fid);
    if ~strcmp(h, hdr), error('v5_envelope_study:csv', '%s has other columns: move it away first', file); end
end
fid = fopen(file, 'a');
if new, fprintf(fid, '%s\n', hdr); end
c = cell(1, numel(f));
for i = 1:numel(f)
    v = row.(f{i});
    if ischar(v), c{i} = ['"' v '"']; else, c{i} = sprintf('%.6g', v); end
end
fprintf(fid, '%s\n', strjoin(c, ','));
fclose(fid);
end
