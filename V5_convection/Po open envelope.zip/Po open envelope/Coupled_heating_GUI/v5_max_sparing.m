function S = v5_max_sparing(R, P, varargin)
%V5_MAX_SPARING  The thickest surface layer that can be kept below T_protect
%                while a lesion still reaches a required depth, and the
%                power envelope that does it.
%
%   S = v5_max_sparing(R, P)                           lesion >= 3 mm at 50 degC
%   S = v5_max_sparing(R, P, 'lesion_depth', 5, 'T_protect', 45, 'T_lesion', 50)
%
%   For each trial layer thickness s the optimal envelope (v5_optimise_envelope,
%   'track': boost, then hold the layer at T_protect) is found; the largest s for
%   which its lesion still reaches 'lesion_depth' is kept (bisection; the lesion
%   shrinks as s grows).  P.P_set is the maximum power, power only for t < P.t_on.
%
%   S.s_max       mm, the thickest protected layer, on the grid rows (NaN if the lesion
%                 cannot be reached even with only the surface row protected; s_hi if the lesion is still
%                 reached at the upper bound).  Use dh = 0.25 mm for finer steps.
%   S.spared      mm, the interpolated layer that never reached T_protect (>= s_max)
%   S.track, S.cw the optimal and the best constant-power runs at s_max
%                 (fields as v5_optimise_envelope: env_t, env_p, lesion, P_mean ...)
%   S.cw_s_max    mm, the best sparing constant power alone can give for the
%                 same lesion depth (for comparison)
%   Options: 'lesion_depth' (mm, 3), 'T_protect' (45), 'T_lesion' (50),
%            's_hi' (mm, 4), 'metric' ('lesion' = ever >= T_lesion,
%            or 'cem' = CEM43 >= 240 min)

o = struct('lesion_depth', 3, 'T_protect', 45, 'T_lesion', 50, 's_hi', 4, 'metric', 'lesion');
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end

trial = @(s) v5_optimise_envelope(R, P, 's_protect', s, 'T_protect', o.T_protect, ...
                                'T_lesion', o.T_lesion, 'verbose', false);
depthOf = @(X) X.(o.metric);

[sT, OutT] = bisect(@(Out) depthOf(Out.track));
[sC, ~]    = bisect(@(Out) depthOf(Out.cw));
S = struct('s_max', sT, 'cw_s_max', sC, 'opt', o);
if isempty(OutT), OutT = trial(0); end
S.track = OutT.track;  S.cw = OutT.cw;  S.spared = OutT.track.spared;
if isnan(sT), S.spared = NaN; end
fprintf('lesion >= %.1f mm at %.0f degC: layer kept < %.0f degC = %.2f mm (optimal envelope; %.2f interpolated), %.2f mm (constant power)\n', ...
        o.lesion_depth, o.T_lesion, o.T_protect, sT, S.spared, sC);

    function [s, best] = bisect(depthFun)
        % the protected layer can only change at grid rows, so search the rows
        zs = -R.z(:).'*1e3;  zs = zs(zs <= o.s_hi + 1e-9);
        best = [];
        Out = trial(zs(1));
        if depthFun(Out) < o.lesion_depth, s = NaN; return, end   % not reachable at all
        best = Out;  lo = 1;  hi = numel(zs);
        Out = trial(zs(hi));
        if depthFun(Out) >= o.lesion_depth, s = zs(hi); best = Out; return, end
        while hi - lo > 1                                % zs(lo) works, zs(hi) does not
            mid = floor((lo + hi)/2);  Out = trial(zs(mid));
            if depthFun(Out) >= o.lesion_depth, lo = mid; best = Out; else, hi = mid; end
        end
        s = zs(lo);
    end
end
