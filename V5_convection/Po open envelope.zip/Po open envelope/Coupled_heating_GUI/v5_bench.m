function B = v5_bench(varargin)
%V5_BENCH  Compare V5 with Edward's thermochromic bench runs (bench/bench_runs.csv).
%
%   B = v5_bench()                         all 25 Aug runs, photo preset, plots
%   B = v5_bench('date', '2026-08-25', 'preset', 'photo', 'set', struct('h_s', 3000), ...
%                'scale', 1, 'plot', true, 'runs', {'2026-08-25_CW3'}, 'R', R)
%
%   Options
%     'date'    only runs on this date ('' = all).  14 Aug: the setup (antenna,
%               distance, bath temperature) is not recorded -- treat with care.
%     'preset'  v5_defaults preset (default 'photo': 12 mm, 1.1 mm, 25 degC bath,
%               which is the photographed 25 Aug 50 W run)
%     'set'     struct of fields overriding the preset (e.g. h_s, P_dropoff, T_tlc)
%     'scale'   the bench mm are divided by this before comparing (default 1).
%               The 50 W CW run of 25 Aug is ~1.25x larger in Edward's sheet than
%               on the registered photographs (photos/README.txt) -- check his scale.
%     'runs'    cell array of run_id to keep (default all on 'date')
%     'R'       a v5_solve result to reuse (must match the solve fields)
%     'plot'    draw the comparison (default true)
%
%   Model numbers are v5_metrics' coloured region (T >= P.T_tlc) on the
%   antenna plane: col_length, col_depth, col_sparing, at the bench times.
%   Each run sets P_set, duty, T_pulse and t_on from the sheet.
%
%   B.rows   one row per bench measurement: run, t, bench L/D/S, model L/D/S
%   B.rms    RMS error (mm) of length, depth, sparing over rows where both exist
%   B.runs   per run: id, P_set, duty, T_pulse, t_on, rms
%   B.P, B.R the settings and the solution used

o = struct('date', '2026-08-25', 'preset', 'photo', 'set', struct(), 'scale', 1, ...
           'runs', {{}}, 'R', [], 'plot', true, 'file', '');
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end
here = fileparts(mfilename('fullpath'));
if isempty(o.file), o.file = fullfile(here, 'bench', 'bench_runs.csv'); end

D = readBench(o.file);
keep = true(size(D.t));
if ~isempty(o.date), keep = keep & strcmp(D.date, o.date); end
if ~isempty(o.runs), keep = keep & ismember(D.run, o.runs); end
D = subsetD(D, keep);
ids = unique(D.run, 'stable');

P = v5_defaults(o.preset);
f = fieldnames(o.set);
for i = 1:numel(f), P.(f{i}) = o.set.(f{i}); end
if isempty(o.R) || ~strcmp(o.R.key, v5_key(P))
    P.t_end = max(P.t_end, ceil(max(D.t_on)/P.dt_frame)*P.dt_frame + 20);
    R = v5_solve(P);
else
    R = o.R;
end

rows = struct('run', {}, 't', {}, 'bL', {}, 'bD', {}, 'bS', {}, 'mL', {}, 'mD', {}, 'mS', {});
runs = struct('id', {}, 'P_set', {}, 'duty', {}, 'T_pulse', {}, 't_on', {}, 'rms', {}, 'M', {});
for k = 1:numel(ids)
    s = strcmp(D.run, ids{k});  i0 = find(s, 1);
    Q = P;
    Q.P_set = D.P_set(i0);  Q.duty = D.duty(i0);  Q.t_on = D.t_on(i0);
    if isfinite(D.T_pulse(i0)), Q.T_pulse = D.T_pulse(i0); end
    Q.t_rest = 0;  Q.env_t = [];  Q.env_p = [];
    O = v5_eval(R, Q);
    M = v5_metrics(R, O, Q, struct('T_colour', Q.T_tlc));
    tb = D.t(s);  sp = M.col_sparing;
    mL = interp1(R.t, M.col_length, tb);
    mD = interp1(R.t, M.col_depth, tb);
    mS = interp1(R.t, sp, tb);                         % NaN where nothing is coloured
    bL = D.L(s)/o.scale;  bD = D.D(s)/o.scale;  bS = D.S(s)/o.scale;
    for j = 1:numel(tb)
        rows(end+1) = struct('run', ids{k}, 't', tb(j), 'bL', bL(j), 'bD', bD(j), 'bS', bS(j), ...
                             'mL', mL(j), 'mD', mD(j), 'mS', mS(j)); %#ok<AGROW>
    end
    runs(end+1) = struct('id', ids{k}, 'P_set', Q.P_set, 'duty', Q.duty, 'T_pulse', D.T_pulse(i0), ...
                         't_on', Q.t_on, 'rms', rmsOf(bL, mL, bD, mD, bS, mS), 'M', M); %#ok<AGROW>
end
B = struct('rows', rows, 'runs', runs, 'P', P, 'R', R, 'opt', o);
B.rms = rmsOf([rows.bL], [rows.mL], [rows.bD], [rows.mD], [rows.bS], [rows.mS]);
fprintf('v5_bench: %d runs, %d measurements.  RMS error  length %.2f  depth %.2f  sparing %.2f mm\n', ...
        numel(runs), numel(rows), B.rms.L, B.rms.D, B.rms.S);
if o.plot, drawBench(B); end
end

% =========================================================================
function r = rmsOf(bL, mL, bD, mD, bS, mS)
f = @(b, m) sqrt(mean((b(isfinite(b) & isfinite(m)) - m(isfinite(b) & isfinite(m))).^2));
r = struct('L', f(bL, mL), 'D', f(bD, mD), 'S', f(bS, mS));
end

function D = readBench(file)
fid = fopen(file, 'r');
if fid < 0, error('v5_bench:file', 'cannot open %s', file); end
c = textscan(fid, '%s %s %f %f %f %f %f %f %f %f', 'Delimiter', ',', 'HeaderLines', 1, ...
             'TreatAsEmpty', {'nan', 'NaN', ''}, 'EmptyValue', NaN);
fclose(fid);
D = struct('date', {c{1}}, 'run', {c{2}}, 'P_set', c{3}, 'duty', c{4}, 'T_pulse', c{5}, ...
           't_on', c{6}, 't', c{7}, 'L', c{8}, 'D', c{9}, 'S', c{10});
end

function D = subsetD(D, k)
f = fieldnames(D);
for i = 1:numel(f), D.(f{i}) = D.(f{i})(k); end
end

function drawBench(B)
ids = {B.runs.id};
fig = figure('Name', 'V5 vs bench', 'Color', 'w', 'Position', [60 60 1300 760]);
lab = {'coloured length (mm)', 'coloured depth (mm)', 'clear top layer = sparing (mm)'};
bf = {'bL', 'bD', 'bS'};  mf = {'mL', 'mD', 'mS'};
cw = [B.runs.duty] >= 1;
groups = {find(cw), find(~cw)};  gname = {'continuous', 'pulsed'};
cols = lines(max(numel(groups{1}), numel(groups{2})));
for g = 1:2
    for q = 1:3
        ax = subplot(2, 3, (g - 1)*3 + q);  hold(ax, 'on');  grid(ax, 'on');
        for j = 1:numel(groups{g})
            k = groups{g}(j);  r = B.runs(k);  s = strcmp({B.rows.run}, r.id);
            M = r.M;
            switch q
                case 1, y = M.col_length;
                case 2, y = M.col_depth;
                case 3, y = M.col_sparing;
            end
            if r.duty < 1
                nm = sprintf('%g W %g%% / %g s', r.P_set, 100*r.duty, r.T_pulse);
            else
                nm = sprintf('%g W CW', r.P_set);
            end
            plot(ax, M.t, y, '-', 'Color', cols(j, :), 'DisplayName', nm);
            plot(ax, [B.rows(s).t], [B.rows(s).(bf{q})], 'o', 'Color', cols(j, :), ...
                 'MarkerFaceColor', cols(j, :), 'HandleVisibility', 'off');
        end
        xlabel(ax, 'time since power on (s)');  ylabel(ax, lab{q});
        title(ax, sprintf('%s: model (lines) vs bench (dots)', gname{g}));
        xlim(ax, [0 max([B.runs.t_on]) + 30]);
        if q == 3, legend(ax, 'Location', 'northeast', 'FontSize', 7); end
    end
end
set(fig, 'UserData', B.opt);
end
