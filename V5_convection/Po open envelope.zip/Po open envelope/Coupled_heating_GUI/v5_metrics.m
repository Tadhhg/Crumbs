function M = v5_metrics(R, O, P, opt)
%V5_METRICS  Sparing, lesion and coloured-region numbers for every stored frame.
%
%   M = v5_metrics(R, O, P)          R from v5_solve, O from v5_eval, P the settings
%   M = v5_metrics(R, O, P, opt)     opt fields (all optional):
%       T_protect  [degC] a node is "spared" while it stays below this   (default 45)
%       T_lesion   [degC] a node is "lesioned" once it reaches this      (default 50)
%       T_colour   [degC] pigment colour start, for the bench numbers    (default P.T_tlc)
%       CEM_lesion [min]  thermal dose that counts as lesion (CEM43)      (default 240)
%
%   Every output is a 1 x nt row (one value per frame, R.t), lengths in mm.
%   Depths are measured down from the gel surface (z = 0) and interpolated
%   between grid nodes, the same way as V4 (gel_heating_eval).
%
%   SNAPSHOT (what the gel looks like at that moment; reversible pigment, V4 D):
%     D_protect   protected depth: the layer below the surface in which
%                 T < T_protect everywhere (min over x).  Inf = nothing is hot.
%     D_lesion    depth where T first reaches T_lesion (min over x); Inf = none
%     les_depth   deepest point with T >= T_lesion (0 = none)
%     T_peak, x_peak, z_peak, T_surf (hottest surface node)
%   BENCH (Edward's measurements: the coloured region, T >= T_colour):
%     col_length  extent of the coloured region along x
%     col_depth   deepest coloured point below the surface
%     col_sparing uncoloured top layer = min over x of the first coloured depth
%                 (NaN while nothing is coloured, as the bench sheet's '-')
%   CUMULATIVE (what an irreversible lesion would record; max over 0..t):
%     Dmax_protect  layer that has NEVER reached T_protect
%     lesmax_depth  deepest point that has EVER reached T_lesion
%     cem_depth     deepest point whose CEM43 dose has reached CEM_lesion
%     cem_sparing   layer whose CEM43 dose is still below CEM_lesion
%   M.t, M.opt echo the frame times and the thresholds.
%
%   Only the antenna plane (y = 0) is stored.  The source is symmetric about
%   it and strongest on it, so the plane holds the largest extent in x and z:
%   it matches a side-view photograph, which sees the projection over y.

if nargin < 4, opt = struct(); end
opt = defaults(opt, P);
T = double(O.T);                            % nz x nx x nt
[nz, nx, nt] = size(T);
x = R.x(:).'*1e3;  depth = -R.z(:)*1e3;     % mm; depth(1) = 0 at the surface
dt = R.t(2) - R.t(1);

M = struct('t', R.t, 'opt', opt);

% ------------------------------------------------------------ SNAPSHOT ---
Tf = reshape(T, nz*nx, nt);
[M.T_peak, ip] = max(Tf, [], 1);
[izp, ixp] = ind2sub([nz nx], ip);
M.x_peak = x(ixp);  M.z_peak = -depth(izp).';
M.T_surf = reshape(max(T(1, :, :), [], 2), 1, nt);
M.D_protect = firstDepth(T, depth, opt.T_protect);
M.D_lesion  = firstDepth(T, depth, opt.T_lesion);
M.les_depth = lastDepth(T, depth, opt.T_lesion);

% --------------------------------------------------------------- BENCH ---
col = T >= opt.T_colour;
anyc = reshape(any(any(col, 1), 2), 1, nt);
colx = reshape(any(col, 1), nx, nt);        % coloured columns
M.col_length = zeros(1, nt);
for n = find(anyc)
    ix = find(colx(:, n));
    M.col_length(n) = edgeX(T(:, :, n), x, opt.T_colour, ix(1), ix(end));
end
M.col_depth = lastDepth(T, depth, opt.T_colour);
M.col_sparing = firstDepth(T, depth, opt.T_colour);
M.col_sparing(~anyc) = NaN;

% ---------------------------------------------------------- CUMULATIVE ---
Tmax = T;
for n = 2:nt, Tmax(:, :, n) = max(Tmax(:, :, n-1), T(:, :, n)); end
M.Dmax_protect = firstDepth(Tmax, depth, opt.T_protect);
M.lesmax_depth = lastDepth(Tmax, depth, opt.T_lesion);
% CEM43 = sum R^(43 - T) dt/60, R = 0.5 above 43 degC and 0.25 below
% (Sapareto & Dewey 1984); trapezoid over the frames
Rb = 0.25 + 0.25*(T >= 43);
rate = Rb.^(43 - T)/60;                      % minutes of 43 degC per second
cem = cumsum(cat(3, zeros(nz, nx), (rate(:, :, 1:end-1) + rate(:, :, 2:end))*dt/2), 3);
M.cem_depth   = lastDepth(cem, depth, opt.CEM_lesion);
M.cem_sparing = firstDepth(cem, depth, opt.CEM_lesion);
M.cem_peak    = reshape(max(max(cem, [], 1), [], 2), 1, nt);
end

% =========================================================================
function opt = defaults(opt, P)
d = struct('T_protect', 45, 'T_lesion', 50, 'T_colour', P.T_tlc, 'CEM_lesion', 240);
f = fieldnames(d);
for i = 1:numel(f)
    if ~isfield(opt, f{i}) || isempty(opt.(f{i})), opt.(f{i}) = d.(f{i}); end
end
end

function D = firstDepth(T, depth, Tc)
% min over x of the depth at which T first reaches Tc going down (interpolated).
% Inf where nothing reaches Tc in that frame.
[nz, nx, nt] = size(T);
above = T >= Tc;
[has, i1] = max(above, [], 1);              % first node at or above Tc, per column/frame
has = reshape(has, nx, nt);  i1 = reshape(i1, nx, nt);
d = inf(nx, nt);
for n = 1:nt
    for ix = find(has(:, n)).'
        i = i1(ix, n);
        if i == 1
            d(ix, n) = 0;
        else
            Ta = T(i-1, ix, n);  Tb = T(i, ix, n);
            d(ix, n) = depth(i-1) + (Tc - Ta)/(Tb - Ta)*(depth(i) - depth(i-1));
        end
    end
end
D = min(d, [], 1);
end

function D = lastDepth(T, depth, Tc)
% deepest point (max over x) at which T >= Tc, interpolated to the crossing
% below it.  0 where nothing reaches Tc.
[nz, nx, nt] = size(T);
above = T >= Tc;
D = zeros(1, nt);
for n = 1:nt
    a = above(:, :, n);
    rows = find(any(a, 2));
    if isempty(rows), continue, end
    i = rows(end);                           % deepest row with any node >= Tc
    if i == nz, D(n) = depth(nz); continue, end
    ix = find(a(i, :));
    [Ta, k] = max(T(i, ix, n));  Tb = T(i+1, ix(k), n);
    D(n) = depth(i) + (Ta - Tc)/max(Ta - Tb, eps)*(depth(i+1) - depth(i));
end
end

function L = edgeX(Tn, x, Tc, i0, i1)
% coloured extent along x on one frame: interpolate both ends on the row
% where they sit (max over depth of each column)
c = max(Tn, [], 1);
lo = x(i0);  hi = x(i1);
if i0 > 1, lo = x(i0-1) + (Tc - c(i0-1))/(c(i0) - c(i0-1))*(x(i0) - x(i0-1)); end
if i1 < numel(x), hi = x(i1) + (c(i1) - Tc)/(c(i1) - c(i1+1))*(x(i1+1) - x(i1)); end
L = hi - lo;
end
