function T = v5_run_case(label, varargin)
%V5_RUN_CASE  Headless V5 runs and sweeps, one CSV row per run with EVERY input.
%
%   v5_run_case('baseline')                                    photo preset, 50 W, 332 s
%   v5_run_case('W water', 'sweep', {'T_b', [5 10 15 20 25]}, 'matched', true)
%   v5_run_case('grid',    'sweep', {'flow', [1 5 10], 'd', [1.1e-3 1.6e-3]}, 'matched', true)
%   v5_run_case('pinned',  'set', struct('h_s', Inf), 'preset', 'photo')
%   T = v5_run_case(...)   also returns the rows as a struct array
%
%   Options (name, value)
%     'preset'    v5_defaults preset                              default 'photo'
%     'set'       struct of fields to change (SI, as in v5_defaults)
%     'sweep'     {'field', values, 'field2', values2, ...}: every combination
%     't_eval'    [s] time at which the numbers are read          default P.t_on
%                 (the treatment time; P.t_on is set to t_eval unless 'set'
%                 gives t_on, so "exposure" means the same as in V4 run_case)
%     'matched'   true: choose P_set so that the hottest point in the plane is
%                 exactly T_lesion at t_eval (V4 "matched power")  default false
%     'T_protect' [degC] sparing threshold                        default 45
%     'T_lesion'  [degC] lesion threshold / matched target        default 50
%     'csv'       file to append to                               default 'v5_sweep_results.csv'
%                 If the file exists with a different header, the rows go to a
%                 new file (name_2.csv, ...) rather than breaking the columns.
%     'plot'      write a PNG per run (map at t_eval + depth profile)   default false
%     'outdir'    folder for the CSV and PNGs                     default ./v5_runs
%
%   Outputs per run (all at t_eval unless named cumulative):
%     P_set_W, P_del_W, protected_mm (V4's D: layer below T_protect now),
%     lesion_top_mm, lesion_depth_mm, peak_C, peak_x_mm, peak_z_mm, surface_max_C,
%     spared_ever_mm and lesion_ever_mm (cumulative 0..t_eval), cem240_depth_mm,
%     colour_length/depth/sparing_mm (T >= T_tlc: the bench numbers),
%     catheter_C, P_gel_frac (share of delivered power absorbed in the block, 3-D)
%   Solutions are cached (per v5_key) for the MATLAB session.

o = struct('preset', 'photo', 'set', struct(), 'sweep', {{}}, 't_eval', [], 'matched', false, ...
           'T_protect', 45, 'T_lesion', 50, 'csv', 'v5_sweep_results.csv', 'plot', false, ...
           'outdir', fullfile(pwd, 'v5_runs'));
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end
if ~exist(o.outdir, 'dir'), mkdir(o.outdir); end

persistent cache
if isempty(cache), cache = containers.Map(); end

% --------------------------------------------------------- the run list --
names = o.sweep(1:2:end);  vals = o.sweep(2:2:end);
nrun = prod(cellfun(@numel, vals));  if isempty(names), nrun = 1; end
T = [];
for r = 1:nrun
    P = v5_defaults(o.preset);
    f = fieldnames(o.set);
    for i = 1:numel(f), P.(f{i}) = o.set.(f{i}); end
    if ~isempty(names)
        sub = cell(1, numel(names));
        [sub{:}] = ind2sub([cellfun(@numel, vals) 1], r);
        for i = 1:numel(names), P.(names{i}) = vals{i}(sub{i}); end
    end
    te = o.t_eval;  if isempty(te), te = P.t_on; end
    if ~isfield(o.set, 't_on'), P.t_on = te; end
    if P.t_end < te + 4*P.dt_frame, P.t_end = ceil((te + 20)/P.dt_frame)*P.dt_frame; end
    n = round(te/P.dt_frame) + 1;

    key = v5_key(P);
    if isKey(cache, key)
        R = cache(key);
    else
        R = v5_solve(P);  cache(key) = R;
        if cache.Count > 8, k = keys(cache); remove(cache, k{1}); end
    end

    mode = 'fixed';
    if o.matched
        mode = 'matched';
        P.P_set = matchPower(R, P, n, o.T_lesion);
    end
    O = v5_eval(R, P);
    M = v5_metrics(R, O, P, struct('T_protect', o.T_protect, 'T_lesion', o.T_lesion));

    row = struct();
    row.label = label;  row.run = r;  row.mode = mode;  row.time = datestr(now, 'yyyy-mm-dd HH:MM:SS');
    row.t_eval_s = R.t(n);
    row.T_protect_C = o.T_protect;  row.T_lesion_C = o.T_lesion;
    pf = paramFields(P);
    for i = 1:numel(pf), row.(['in_' pf{i}]) = scalarOf(P.(pf{i})); end
    row.P_del_W = O.P_del;
    row.protected_mm = M.D_protect(n);
    row.lesion_top_mm = M.D_lesion(n);
    row.lesion_depth_mm = M.les_depth(n);
    row.peak_C = M.T_peak(n);  row.peak_x_mm = M.x_peak(n);  row.peak_z_mm = M.z_peak(n);
    row.surface_max_C = M.T_surf(n);
    row.spared_ever_mm = M.Dmax_protect(n);
    row.lesion_ever_mm = M.lesmax_depth(n);
    row.cem240_depth_mm = M.cem_depth(n);
    row.colour_length_mm = M.col_length(n);
    row.colour_depth_mm = M.col_depth(n);
    row.colour_sparing_mm = M.col_sparing(n);
    row.catheter_C = O.T_cath(n);
    row.P_gel_frac = R.P_gel;
    if o.plot, row.figure = drawRun(R, O, P, M, n, o, label, r); else, row.figure = ''; end
    writeRow(fullfile(o.outdir, o.csv), row);
    T = [T row]; %#ok<AGROW>
    fprintf('%s #%d (%s): P_set %.1f W, peak %.1f degC, protected %.2f mm, lesion %.2f mm, colour sparing %.2f mm\n', ...
            label, r, mode, P.P_set, row.peak_C, row.protected_mm, row.lesion_depth_mm, row.colour_sparing_mm);
end
end

% =========================================================================
function Pw = matchPower(R, P, n, Tt)
% hottest point in the plane at frame n = Tt.  T = B + P_set*U exactly
% (dielectric and catheter both scale with P_set), so bisect on P_set.
Q = P;  Q.P_set = 0;  O0 = v5_eval(R, Q);  B = double(O0.T(:, :, n));
Q.P_set = 1;          O1 = v5_eval(R, Q);  U = double(O1.T(:, :, n)) - B;
f = @(p) max(B(:) + p*U(:)) - Tt;
if f(0) >= 0, Pw = 0; return, end
lo = 0;  hi = 10;
while f(hi) < 0, hi = 2*hi;  if hi > 1e6, error('v5_run_case:match', 'cannot reach %.1f degC', Tt); end, end
for it = 1:60
    m = (lo + hi)/2;
    if f(m) < 0, lo = m; else, hi = m; end
end
Pw = hi*(1 + 1e-5);                         % peak at (or a hair above) the target: survives single-precision storage
end

function f = paramFields(P)
% every input field in a fixed order (v5_defaults order), minus bookkeeping
f = fieldnames(v5_defaults('table'));
f = f(~strcmp(f, 'preset'));
end

function v = scalarOf(x)
if ischar(x), v = x;
elseif isempty(x), v = NaN;
elseif numel(x) == 1, v = x;
else, v = sprintf('%d values', numel(x));        % env_t / env_p: see the figure or the script
end
end

function writeRow(file, row)
f = fieldnames(row);
hdr = strjoin(f.', ',');
[d, stem, ext] = fileparts(file);
k = 1;
while exist(file, 'file')
    fid = fopen(file, 'r');  h = fgetl(fid);  fclose(fid);
    if strcmp(h, hdr), break, end
    k = k + 1;  file = fullfile(d, sprintf('%s_%d%s', stem, k, ext));
end
new = ~exist(file, 'file');
fid = fopen(file, 'a');
if new, fprintf(fid, '%s\n', hdr); end
c = cell(1, numel(f));
for i = 1:numel(f)
    v = row.(f{i});
    if ischar(v), c{i} = ['"' strrep(v, '"', '''') '"'];
    elseif isinf(v), c{i} = sprintf('%s', tern(v > 0, 'Inf', '-Inf'));
    else, c{i} = sprintf('%.10g', v);
    end
end
fprintf(fid, '%s\n', strjoin(c, ','));
fclose(fid);
end

function s = tern(c, a, b)
if c, s = a; else, s = b; end
end

function file = drawRun(R, O, P, M, n, o, label, r)
x = R.x*1e3;  z = R.z*1e3;  Tn = double(O.T(:, :, n));
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 1100 420]);
ax = subplot(1, 3, [1 2]);
imagesc(ax, x, z, Tn);  set(ax, 'YDir', 'normal');  axis(ax, 'image');  hold(ax, 'on');
colormap(ax, jet(256));  caxis(ax, [min(20, min(Tn(:))) max(60, max(Tn(:)))]);  colorbar(ax);
contour(ax, x, z, Tn, [o.T_protect o.T_protect], 'w--', 'LineWidth', 1.2);
contour(ax, x, z, Tn, [o.T_lesion o.T_lesion], 'k-', 'LineWidth', 1.2);
if isfinite(M.D_protect(n)), plot(ax, x([1 end]), -M.D_protect(n)*[1 1], 'c-', 'LineWidth', 1.2); end
plot(ax, [0 P.L*1e3], P.d*1e3*[1 1], 'k-', 'LineWidth', 2);
ylim(ax, [z(end) P.d*1e3 + 1]);
xlabel(ax, 'x (mm), feed at 0');  ylabel(ax, 'z (mm)');
title(ax, sprintf('%s #%d  t = %.0f s  P_{set} %.1f W  peak %.1f C  protected %.2f mm', ...
      label, r, R.t(n), P.P_set, M.T_peak(n), M.D_protect(n)), 'Interpreter', 'tex');
ax2 = subplot(1, 3, 3);
[~, ix] = max(max(Tn, [], 1));
plot(ax2, Tn(:, ix), z, 'k-', 'LineWidth', 1.5);  hold(ax2, 'on');  grid(ax2, 'on');
plot(ax2, o.T_protect*[1 1], z([1 end]), 'k--');  plot(ax2, o.T_lesion*[1 1], z([1 end]), 'k-');
xlabel(ax2, 'T (degC)');  ylabel(ax2, 'z (mm)');  title(ax2, sprintf('profile at x = %.1f mm', x(ix)));
file = fullfile(o.outdir, sprintf('%s_%d.png', regexprep(label, '[^\w]', '_'), r));
print(fig, file, '-dpng', '-r130');
close(fig);
end
