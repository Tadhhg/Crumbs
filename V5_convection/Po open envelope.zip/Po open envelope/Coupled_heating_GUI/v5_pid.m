function S = v5_pid(R, P, varargin)
%V5_PID  Closed-loop power control on the V5 model: a PID loop that holds a
%        temperature sensor at a setpoint by adjusting the generator power.
%
%   S = v5_pid(R, P)                                     auto-tuned PI, ideal sensor
%   S = v5_pid(R, P, 'sensor', [3.5 1.0], 'T_set', 44, 'Kp', 0.05, 'Ki', 0.002, ...)
%
%   R from v5_solve; P the settings with P.P_set = the MAXIMUM power (u = 1).
%   Power is only allowed for t < P.t_on.  The controller runs once per stored
%   frame (R.P.dt_frame, 2 s by default) and its output is held over the frame.
%
%   Options
%     'sensor'     'layer'   = the hottest node within s_protect of the surface
%                              (an ideal sensor: the best any controller can see)
%                  [x z]     = one fixed point, mm (x along the element, z = depth
%                              below the surface, positive), e.g. a fibre-optic probe
%                  'catheter'= the lumped catheter-tip temperature (what a tip
%                              thermocouple would read)
%     's_protect'  mm, depth of the protected layer (for 'layer' and the report)  1
%     'T_protect'  degC, the limit the layer must stay below (report only)       45
%     'T_lesion'   degC                                                           50
%     'T_set'      degC setpoint for the SENSOR               default T_protect - 0.5
%     'Kp','Ki','Kd'  gains in (fraction of P_set) per K, per K s, per K/s.
%                  [] (default) = auto: IMC PI tuning from the sensor's step response
%     'lambda'     s, closed-loop time constant for the auto tuning   default tau/2
%     'delay'      frames of sensor delay                              default 0
%     'noise'      K, standard deviation of sensor noise               default 0
%     'seed'       random seed for the noise                           default 1
%
%   S: a, env_t, env_p (apply with P.env_t / P.env_p), y (sensor reading per frame),
%      gains, M (v5_metrics), lesion, spared, T_peak, T_layer_max, overshoot (K above
%      T_protect in the layer; > 0 means the protected layer was breached),
%      t_lesion90, P_mean, energy.  Compare with v5_optimise_envelope's 'track',
%      which is the optimum a perfect controller could reach.

o = struct('sensor', 'layer', 's_protect', 1, 'T_protect', 45, 'T_lesion', 50, 'T_set', [], ...
           'Kp', [], 'Ki', [], 'Kd', 0, 'lambda', [], 'delay', 0, 'noise', 0, 'seed', 1);
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end
if isempty(o.T_set), o.T_set = o.T_protect - 0.5; end

P.duty = 1;  P.t_rest = 0;  P.env_t = [];  P.env_p = [];
L = v5_linear(R, P);
nt = numel(R.t);  nz = L.nz;  nx = L.nx;  dt = L.dt;
depth = -R.z(:)*1e3;  on = R.t(1:end-1) < P.t_on;
[ZZ, ~] = ndgrid(1:nz, 1:nx);
lay = find(depth(ZZ) <= o.s_protect + 1e-9);

% ---------------------------------------------------------------- sensor --
catheter = ischar(o.sensor) && strcmpi(o.sensor, 'catheter');
if catheter
    % catheter-tip temperature is linear in the envelope too: its own impulse response
    P0 = P;  P0.P_set = 0;  Oc0 = v5_eval(R, P0);
    P1 = P;  P1.t_on = R.t(end) + dt;  P1.env_t = [0 dt];  P1.env_p = [1 0];  Oc1 = v5_eval(R, P1);
    Y0 = Oc0.T_cath(:).';  Hy = Oc1.T_cath(2:end) - Oc0.T_cath(2:end);
    sidx = [];
elseif ischar(o.sensor)                                   % 'layer'
    sidx = lay;  Y0 = [];  Hy = [];
else
    [~, ix] = min(abs(R.x*1e3 - o.sensor(1)));  [~, iz] = min(abs(depth - o.sensor(2)));
    sidx = sub2ind([nz nx], iz, ix);  Y0 = [];  Hy = [];
end
readY = @(Tf, n) max(Tf(:, n));

% ------------------------------------------------------------ auto tuning --
if isempty(o.Kp) || isempty(o.Ki)
    if catheter
        step = Y0 + cumsum([0 Hy]);                      % response to full power held on
    else
        step = max(L.T0(sidx, :) + cumsum([zeros(numel(sidx), 1) L.H(sidx, :)], 2), [], 1);
    end
    base = step(1);  rise = step - base;
    Kg = rise(end);                                       % K per unit amplitude (end of stored run)
    k63 = find(rise >= 0.632*Kg, 1);
    tau = max(R.t(k63), dt);
    lam = o.lambda;  if isempty(lam), lam = tau/2; end
    theta = dt*(1 + o.delay);
    Kp = tau/(Kg*(lam + theta));
    Ki = Kp/tau;
    if isempty(o.Kp), o.Kp = Kp; end
    if isempty(o.Ki), o.Ki = Ki; end
end

% -------------------------------------------------------------- the loop --
if o.noise > 0, randn('seed', o.seed); end %#ok<RAND>
a = zeros(1, nt - 1);  y = nan(1, nt - 1);
if catheter
    Yf = Y0;
else
    Tf = L.T0(sidx, :);
end
I = 0;  eprev = NaN;
for m = 1:nt - 1
    if ~on(m), continue, end
    k = max(m - o.delay, 1);                              % delayed reading
    if catheter, ym = Yf(k); else, ym = readY(Tf, k); end
    ym = ym + o.noise*randn;
    y(m) = ym;
    e = o.T_set - ym;
    de = 0;  if isfinite(eprev), de = (e - eprev)/dt; end
    u = o.Kp*e + o.Ki*(I + e*dt) + o.Kd*de;
    if (u < 1 && u > 0) || (u >= 1 && e < 0) || (u <= 0 && e > 0)
        I = I + e*dt;                                     % conditional integration (anti-windup)
    end
    u = min(max(o.Kp*e + o.Ki*I + o.Kd*de, 0), 1);
    a(m) = u;  eprev = e;
    if catheter
        Yf(m+1:nt) = Yf(m+1:nt) + u*Hy(1:nt - m);
    else
        Tf(:, m+1:nt) = Tf(:, m+1:nt) + u*L.H(sidx, 1:nt - m);
    end
end

% ---------------------------------------------------------------- report --
T = L.apply(a);
O = struct('T', reshape(single(T), nz, nx, nt));
M = v5_metrics(R, O, P, struct('T_protect', o.T_protect, 'T_lesion', o.T_lesion));
S = struct('a', a, 'env_t', R.t(1:end-1), 'env_p', a, 'y', y, 'M', M, 'opt', o, ...
           'gains', [o.Kp o.Ki o.Kd]);
S.P_mean = P.P_set*sum(a)*dt/max(P.t_on, eps);
S.energy = P.P_set*sum(a)*dt;
S.lesion = M.lesmax_depth(end);
S.cem = M.cem_depth(end);
S.spared = min(M.Dmax_protect(end), 99);
S.T_peak = max(M.T_peak);
S.T_layer_max = max(max(T(lay, :)));
S.overshoot = S.T_layer_max - o.T_protect;
k = find(M.lesmax_depth >= 0.9*S.lesion, 1);
if S.lesion > 0 && ~isempty(k), S.t_lesion90 = R.t(k); else, S.t_lesion90 = NaN; end
end
