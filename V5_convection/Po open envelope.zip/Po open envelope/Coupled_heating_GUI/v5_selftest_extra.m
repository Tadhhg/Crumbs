function ok = v5_selftest_extra()
%V5_SELFTEST_EXTRA  Checks of the tools added on 2026-09-29 (v5_envelope custom
%   amplitude, v5_linear, v5_metrics, v5_optimise_envelope, v5_run_case).
%   Prints PASS/FAIL.  Run v5_selftest first for the solver itself.  ~1 min.

ok = true;
P = v5_defaults('table');  P.dh = 1e-3;  P.dim = 3;
R = v5_solve(P);  nt = numel(R.t);

% ---- 1 custom amplitude --------------------------------------------------
A = v5_eval(R, P);
Q = P;  Q.env_t = [0 100 200];  Q.env_p = [1 1 1];  B = v5_eval(R, Q);
d = abs(A.T(:) - B.T(:));
ok = check(ok, 'custom amplitude of ones = the CW run', max(d) == 0);
Q.env_p = [1 0.5 0];  B = v5_eval(R, Q);
ok = check(ok, sprintf('custom 1 / 0.5 / 0 steps: mean on %.4f (expect %.4f)', B.env.mean_on, 150/360), ...
           abs(B.env.mean_on - 150/360) < 1e-9 && B.env.pbar(26) == 1 && B.env.pbar(76) == 0.5 && B.env.pbar(126) == 0);
Q = P;  Q.duty = 0.5;  Q.T_pulse = 10;  Q.env_t = [0 180];  Q.env_p = [1 0.5];  B = v5_eval(R, Q);
ok = check(ok, 'amplitude multiplies the pulse train', abs(B.env.mean_on - 0.375) < 1e-9);

% ---- 2 linear map ---------------------------------------------------------
L = v5_linear(R, P);
rand('seed', 1);  a = rand(1, nt - 1);  a(R.t(1:end-1) >= P.t_on) = 0; %#ok<RAND>
Q = P;  Q.env_t = R.t(1:end-1);  Q.env_p = a;  Q.t_on = R.t(end) + 1;
O = v5_eval(R, Q);
d = abs(L.apply(a) - double(reshape(O.T, [], nt)));
ok = check(ok, sprintf('v5_linear = v5_eval for a random envelope (max %.1e K)', max(d(:))), max(d(:)) < 1e-3);

% ---- 3 metrics on a known field ------------------------------------------
Rm = struct('x', (0:10)*1e-3, 'z', -(0:20)*0.5e-3, 't', [0 2]);
depth = -Rm.z(:)*1e3;                                   % 0..10 mm
Tc = 40 + 4*depth - 0.8*depth.^2;                       % peak 45 degC at 2.5 mm
Tf = repmat(Tc, 1, 11);  Tf(:, [1 11]) = 30;            % two cold edge columns
Om = struct('T', cat(3, Tf, Tf));
Pm = struct('T_tlc', 44);
Mm = v5_metrics(Rm, Om, Pm, struct('T_protect', 42, 'T_lesion', 44.5));
% analytic: 42 at depth 0.5635; 44 at 1.3820 and 3.6180; 44.5 at 1.7094, 3.2906
ok = check(ok, sprintf('protected depth = 0.564 mm (got %.3f; linear interpolation)', Mm.D_protect(1)), ...
           abs(Mm.D_protect(1) - 0.5635) < 0.06);
ok = check(ok, sprintf('lesion from %.3f to %.3f mm (exact 1.709 .. 3.291)', Mm.D_lesion(1), Mm.les_depth(1)), ...
           abs(Mm.D_lesion(1) - 1.7094) < 0.06 && abs(Mm.les_depth(1) - 3.2906) < 0.06);
ok = check(ok, sprintf('coloured length %.2f mm (columns 1..9 mm plus the interpolated ends)', Mm.col_length(1)), ...
           Mm.col_length(1) > 8 && Mm.col_length(1) < 10);

% ---- 4 envelope design ----------------------------------------------------
Pe = P;  Pe.P_set = 100;
Out = v5_optimise_envelope(R, Pe, 's_protect', 1, 'verbose', false);
lay = depth_of(R) <= 1 + 1e-9;
for m = {'cw', 'track'}
    S = Out.(m{1});
    Q = Pe;  Q.env_t = S.env_t;  Q.env_p = S.env_p;
    O = v5_eval(R, Q);
    Tl = O.T(lay, :, :);
    ok = check(ok, sprintf('%s envelope keeps the top 1 mm <= 45 degC through v5_eval (max %.3f)', m{1}, max(Tl(:))), ...
               max(Tl(:)) <= 45 + 1e-3);
end
ok = check(ok, sprintf('track delivers at least the CW energy (%.0f vs %.0f J)', Out.track.energy, Out.cw.energy), ...
           Out.track.energy >= Out.cw.energy - 1);

% ---- 5 run_case matched ---------------------------------------------------
d0 = tempname;  mkdir(d0);
Tr = v5_run_case('selftest', 'preset', 'table', 'set', struct('dh', 1e-3), 'matched', true, ...
                 'outdir', d0, 'csv', 'x.csv');
ok = check(ok, sprintf('matched power puts the peak at 50 degC (%.4f)', Tr.peak_C), abs(Tr.peak_C - 50) < 1e-3);
Tr2 = v5_run_case('selftest', 'preset', 'table', 'set', struct('dh', 1e-3, 'T_b', 30), 'outdir', d0, 'csv', 'x.csv');
fid = fopen(fullfile(d0, 'x.csv'));  h = fgetl(fid);  l1 = fgetl(fid);  l2 = fgetl(fid);  fclose(fid);
nf = @(s) numel(strfind(s, ',')) + 1;
ok = check(ok, sprintf('CSV: header and rows have the same %d columns', nf(h)), nf(h) == nf(l1) && nf(h) == nf(l2));

if ok, fprintf('\nALL PASS\n'); else, fprintf('\nSOME CHECKS FAILED\n'); end
end

function d = depth_of(R)
d = -R.z(:)*1e3;
end

function ok = check(ok, msg, cond)
if cond, fprintf('PASS  %s\n', msg); else, fprintf('FAIL  %s\n', msg); ok = false; end
end
