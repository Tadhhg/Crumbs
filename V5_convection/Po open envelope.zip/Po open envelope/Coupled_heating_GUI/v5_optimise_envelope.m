function Out = v5_optimise_envelope(R, P, varargin)
%V5_OPTIMISE_ENVELOPE  The power envelope that heats deepest while a surface
%                      layer stays below a temperature limit, against CW.
%
%   Out = v5_optimise_envelope(R, P)
%   Out = v5_optimise_envelope(R, P, 's_protect', 1, 'T_protect', 45, 'T_lesion', 50, ...)
%
%   R from v5_solve, P the settings.  P.P_set is the MAXIMUM generator power
%   (amplitude 1); power may only be on for t < P.t_on.  The pulse/burst
%   settings in P are ignored: the envelope is what is designed.
%
%   Constraint: every node within s_protect (mm) of the gel surface stays
%   below T_protect at every stored time (0..t_end, cool-down included).
%   Optional: 'T_max' caps every node in the plane (e.g. 95 degC, no boiling).
%
%   Methods (Out.cw, Out.track, and Out.lp when requested)
%     cw     constant power: the largest amplitude that keeps the constraint
%            (bisection).  This is V4's "matched power".
%     track  full power until the protected layer is about to reach the limit,
%            then just enough power to hold it there: each frame gets the
%            largest amplitude for which switching off immediately afterwards
%            would still keep the constraint for the rest of the run.  Heating
%            is linear with non-negative responses, so the envelope can never
%            break the constraint later.  On the V5 table preset this matched
%            the linear-programming optimum to the joule (see V5_UPDATE_NOTES.md).
%     lp     ('lp', true) the exact linear-programming optimum that maximises
%            the temperature at one target node at t_on (linprog, Optimization
%            Toolbox, or glpk in Octave).  Slow; for checking 'track'.
%
%   Each method returns: a (1 x nt-1 amplitude per frame), env_t / env_p
%   (ready for P.env_t / P.env_p: v5_eval and the GUI), P_mean (W, generator,
%   over the treatment), energy (J, generator), and M = v5_metrics of the
%   resulting run, plus the headline numbers:
%     lesion      deepest point that ever reached T_lesion (mm)
%     cem         deepest point with CEM43 >= 240 min (mm)
%     spared      layer that never reached T_protect (mm)
%     T_peak      hottest temperature ever (degC)
%     t_lesion90  time at which the lesion reached 90 % of its final depth (s)
%   Out.table prints them side by side.
%
%   Apply the result in a script:   P.env_t = Out.track.env_t;  P.env_p = Out.track.env_p;
%   or in the GUI:  u = fig.UserData;  u.setParam('env_p', []);
%                   u.setParam('env_t', Out.track.env_t);  u.setParam('env_p', Out.track.env_p);

o = struct('s_protect', 1, 'T_protect', 45, 'T_lesion', 50, 'T_max', Inf, ...
           'lp', false, 'lp_depth', [], 'tol', 0.01, 'verbose', true);
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end

P.duty = 1;  P.t_rest = 0;  P.env_t = [];  P.env_p = [];
L = v5_linear(R, P);
nt = numel(R.t);  nz = L.nz;  nx = L.nx;
depth = -R.z(:)*1e3;
on = R.t(1:end-1) < P.t_on;                     % frames that may carry power

[ZZ, ~] = ndgrid(1:nz, 1:nx);
idxC = find(depth(ZZ) <= o.s_protect + 1e-9);   % protected layer, all x
lim  = (o.T_protect - o.tol)*ones(numel(idxC), 1);
if isfinite(o.T_max)                            % global cap: every node
    idxC = (1:nz*nx).';  lim = (o.T_max - o.tol)*ones(nz*nx, 1);
    lay = depth(ZZ(:)) <= o.s_protect + 1e-9;
    lim(lay) = o.T_protect - o.tol;
end

Out = struct('opt', o, 'P', P, 'L', L);

% ------------------------------------------------------------------ CW ---
lo = 0;  hi = 1;
if ~feasible(1)
    for it = 1:40
        m = (lo + hi)/2;
        if feasible(m), lo = m; else, hi = m; end
    end
else
    lo = 1;
end
Out.cw = finish(lo*on);

% --------------------------------------------------------------- TRACK ---
a = zeros(1, nt - 1);
Tfree = L.T0(idxC, :);                          % the run if the power went off now
for m = find(on)
    G = L.H(idxC, 1:nt - m);                    % one frame of full power, seen at m+1..nt
    room = lim - Tfree(:, m+1:nt);
    pos = G > 1e-9*max(G(:));
    if any(room(:) < 0 & pos(:)), amax = 0;
    elseif any(pos(:)), amax = min(1, min(room(pos)./G(pos)));
    else, amax = 1;
    end
    a(m) = max(amax, 0);
    Tfree(:, m+1:nt) = Tfree(:, m+1:nt) + a(m)*G;
end
Out.track = finish(a);

% ------------------------------------------------------------------ LP ---
if o.lp
    Out.lp = solveLP();
end

Out.table = summary(Out);
if o.verbose, fprintf('%s', Out.table); end

% =========================================================================
    function ok = feasible(c)
        T = L.rows(idxC, c*on);
        ok = all(all(T <= lim));
    end

    function S = finish(a)
        T = L.apply(a);
        O = struct('T', reshape(single(T), nz, nx, nt));
        M = v5_metrics(R, O, P, struct('T_protect', o.T_protect, 'T_lesion', o.T_lesion));
        S = struct();
        S.a = a;
        S.env_t = R.t(1:end-1);  S.env_p = a;
        S.P_mean = P.P_set*sum(a)*L.dt/max(P.t_on, eps);
        S.energy = P.P_set*sum(a)*L.dt;
        S.M = M;
        S.lesion = M.lesmax_depth(end);
        S.cem = M.cem_depth(end);
        S.spared = min(M.Dmax_protect(end), 99);
        S.T_peak = max(M.T_peak);
        k = find(M.lesmax_depth >= 0.9*S.lesion, 1);
        if S.lesion > 0 && ~isempty(k), S.t_lesion90 = R.t(k); else, S.t_lesion90 = NaN; end
    end

    function S = solveLP()
        % maximise T(target, t_on) subject to T(idxC, n) <= lim for all n
        vars = find(on);  nv = numel(vars);
        rows = {};  rhs = {};
        for n = 2:nt
            An = zeros(numel(idxC), nv);
            for j = 1:nv
                if vars(j) < n, An(:, j) = L.H(idxC, n - vars(j)); end
            end
            k = any(An, 2);
            rows{end+1} = An(k, :);  rhs{end+1} = lim(k) - L.T0(idxC(k), n); %#ok<AGROW>
        end
        A = vertcat(rows{:});  b = vertcat(rhs{:});
        n_on = find(R.t <= P.t_on, 1, 'last');
        Tq = L.apply(Out.cw.a);
        [~, i] = max(Tq(:, n_on));  [~, ixs] = ind2sub([nz nx], i);
        zt = o.lp_depth;  if isempty(zt), zt = max(Out.cw.lesion, o.s_protect + 1); end
        [~, izs] = min(abs(depth - zt));
        node = sub2ind([nz nx], izs, ixs);
        c = zeros(nv, 1);
        for j = 1:nv
            if vars(j) < n_on, c(j) = L.H(node, n_on - vars(j)); end
        end
        if exist('linprog', 'file')
            opts = optimoptions('linprog', 'Display', 'off');
            x = linprog(-c, A, b, [], [], zeros(nv, 1), ones(nv, 1), opts);
        elseif exist('glpk', 'file') || exist('glpk', 'builtin')
            x = glpk(c, A, b, zeros(nv, 1), ones(nv, 1), repmat('U', size(A, 1), 1), repmat('C', nv, 1), -1);
        else
            error('v5_optimise_envelope:lp', 'needs linprog (Optimization Toolbox) or glpk (Octave)');
        end
        aa = zeros(1, nt - 1);  aa(vars) = x(:).';
        S = finish(aa);
        S.target = [R.x(ixs)*1e3, -depth(izs)];
    end
end

function s = summary(Out)
m = {'cw', 'track', 'lp'};
s = sprintf(['\nEnvelope design: surface layer %.2g mm kept below %.4g degC; lesion = ever >= %.4g degC\n' ...
             '  P_set (max) %.4g W, power allowed for t < %.4g s, run stored to %.4g s\n' ...
             '  %-6s %9s %9s %10s %10s %9s %9s %11s\n'], ...
             Out.opt.s_protect, Out.opt.T_protect, Out.opt.T_lesion, Out.P.P_set, Out.P.t_on, Out.L.t(end), ...
             'method', 'mean W', 'energy J', 'lesion mm', 'CEM240 mm', 'spared', 'peak C', 't90 lesion');
for i = 1:numel(m)
    if ~isfield(Out, m{i}), continue, end
    S = Out.(m{i});
    s = [s sprintf('  %-6s %9.2f %9.0f %10.2f %10.2f %9.2f %9.2f %11.0f\n', ...
                   m{i}, S.P_mean, S.energy, S.lesion, S.cem, S.spared, S.T_peak, S.t_lesion90)]; %#ok<AGROW>
end
end
