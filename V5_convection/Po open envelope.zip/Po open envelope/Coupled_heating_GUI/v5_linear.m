function L = v5_linear(R, P)
%V5_LINEAR  The V5 model as one linear map from the power envelope to the
%           temperature, for fast envelope design (optimisers, controllers).
%
%   L = v5_linear(R, P)
%       R   from v5_solve;  P the settings.  P.P_set is the FULL-SCALE power:
%           an envelope a(m) = 1 means P_set for that frame.  Everything that
%           is not the envelope (water, flow, catheter constants ...) is taken
%           from P and frozen into L.
%
%   T(:, n) = L.T0(:, n) + sum_{m < n} a(m) L.H(:, n - m)          (exact)
%       a(m)   mean amplitude over frame m = [t(m), t(m+1)), 0..1, m = 1..nt-1
%       L.T0   nz*nx x nt: the gel with the power off (walls, start temperature)
%       L.H    nz*nx x (nt-1): response at lag k frames to one frame of full power
%              (dielectric heating AND the catheter it drives: both are linear
%              and time-invariant in V5, so a single impulse response is exact)
%
%   L.apply(a)          -> nz*nx x nt temperatures for an envelope a (1 x nt-1)
%   L.rows(idx, a)      -> the same for the nodes idx only (fast)
%   L.nz, L.nx, L.t, L.dt, L.P
%
%   Check: v5_selftest_extra compares L.apply against v5_eval for a random
%   envelope (agreement to single precision).

t = R.t;  nt = numel(t);  dt = t(2) - t(1);
[nz, nx, ~] = size(R.D);

P0 = P;  P0.P_set = 0;  P0.env_t = [];  P0.env_p = [];
O0 = v5_eval(R, P0);
T0 = double(reshape(O0.T, nz*nx, nt));

P1 = P;  P1.duty = 1;  P1.t_rest = 0;  P1.t_on = t(end) + dt;
P1.env_t = [0 dt];  P1.env_p = [1 0];           % full power during frame 1 only
O1 = v5_eval(R, P1);
h = double(reshape(O1.T, nz*nx, nt)) - T0;      % h(:, k+1) = response at lag k

H = h(:, 2:end);
L = struct();
L.T0 = T0;  L.H = H;
L.nz = nz;  L.nx = nx;  L.t = t;  L.dt = dt;  L.P = P;
L.apply = @(a) T0 + H*toepA(a, nt);
L.rows  = @(idx, a) T0(idx, :) + H(idx, :)*toepA(a, nt);
end

function M = toepA(a, nt)
% M(k, n) = a(n - k) for 1 <= k <= n-1: T(:, n) = sum_k H(:, k) a(n - k)
a = a(:).';
M = zeros(nt - 1, nt);
for n = 2:nt
    M(1:n-1, n) = a(n-1:-1:1);
end
end
