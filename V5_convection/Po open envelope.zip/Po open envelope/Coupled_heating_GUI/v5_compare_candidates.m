function S = v5_compare_candidates(varargin)
%V5_COMPARE_CANDIDATES  Watch the 5 candidate envelopes side by side and record it.
%
%   S = v5_compare_candidates()                       Edward's bench, 5 L/min, plays on screen
%   S = v5_compare_candidates('video', true)          ...and saves v5_envelope/candidates.mp4
%   S = v5_compare_candidates('flow', 4, 'look', 'pigment', 'every', 2, 'video', true)
%
%   Five gel maps (the antenna plane, as in the GUI) run in step, one per
%   candidate, with the colour-start isotherm (dashed) and the 1 mm clear-layer
%   line (cyan).  The bottom-right panel traces colour depth for all five, with a
%   moving time cursor.  At the end a scorecard is printed and returned in S.
%
%   Candidates (generator watts; see the team table):
%     1 Robust optimal   90 W burst easing to ~25 W (computed here for flow*(1-dip))
%     2 6-step           83.5, 57, 40.5, 30.5, 26, 24.5 W from 0, 2, 6, 20, 60, 150 s
%     3 Constant         25 W
%     4 Short boost      62 W for 5 s, then 25 W
%     5 Pulsed           29.7 W, 80 % duty, 10 s period
%
%   Options
%     'flow'   L/min actually running (surface cooling follows it, v5_flow_hs)   5
%     'dip'    fraction the robust envelope is designed for (0.2 = 20 % dip)    0.2
%     'look'   'temp' (degC map) or 'pigment' (coloured like the gel photos)    'temp'
%     'every'  show every n-th stored frame (1 = every 2 s)                     2
%     'video'  true: write an MP4 (VideoWriter)                                 false
%     'file'   video file name                         'v5_envelope/candidates.mp4'
%     'fps'    video frames per second                                          15
%     'pause'  seconds between frames on screen                                 0
%     'show'   false: skip the animation, just print the scorecard            true

o = struct('flow', 5, 'dip', 0.2, 'look', 'temp', 'every', 2, 'video', false, ...
           'file', fullfile(pwd, 'v5_envelope', 'candidates.mp4'), 'fps', 15, 'pause', 0, 'show', true);
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end

% ------------------------------------------------------------- the model --
P = v5_defaults('photo');  P.P_set = 90;  P.t_on = 360;  P.flow = o.flow;  P = v5_flow_hs(P);
R = v5_solve(P);
Pd = P;  Pd.flow = o.flow*(1 - o.dip);  Pd = v5_flow_hs(Pd);  Rd = v5_solve(Pd);
lim = P.T_tlc;
Out = v5_optimise_envelope(Rd, Pd, 's_protect', 1, 'T_protect', lim, 'T_lesion', lim, 'verbose', false);

names = {'1  Robust optimal', '2  6-step', '3  Constant 25 W', '4  Short boost', '5  Pulsed 80 %'};
Q = repmat({P}, 1, 5);
Q{1}.env_t = Out.track.env_t;  Q{1}.env_p = Out.track.env_p;
Q{2}.env_t = [0 2 6 20 60 150];  Q{2}.env_p = [83.5 57 40.5 30.5 26 24.5]/90;
Q{3}.P_set = 25;
Q{4}.env_t = [0 5];  Q{4}.env_p = [62 25]/90;
Q{5}.P_set = 29.7;  Q{5}.duty = 0.8;  Q{5}.T_pulse = 10;

O = cell(1, 5);  M = cell(1, 5);
for k = 1:5
    O{k} = v5_eval(R, Q{k});
    M{k} = v5_metrics(R, O{k}, Q{k}, struct('T_protect', lim, 'T_lesion', lim, 'T_colour', lim));
end
x = R.x*1e3;  z = R.z*1e3;  t = R.t;  nt = numel(t);

% ------------------------------------------------------------- scorecard --
S = struct('candidate', names, 'mean_W', [], 'sparing_mm', [], 'depth_mm', [], 'onset_s', [], 'length_mm', []);
nOn = find(t <= P.t_on, 1, 'last');
for k = 1:5
    E = O{k}.env;
    S(k).mean_W = Q{k}.P_set*E.mean_on;
    S(k).sparing_mm = min(M{k}.Dmax_protect(end), 99);
    S(k).depth_mm = M{k}.lesmax_depth(end);
    k1 = find(M{k}.lesmax_depth > 1, 1);  S(k).onset_s = NaN;  if ~isempty(k1), S(k).onset_s = t(k1); end
    S(k).length_mm = M{k}.col_length(nOn);
end

% ------------------------------------------------------------- the movie --
if o.show
fig = figure('Color', 'w', 'Position', [40 60 1500 820], 'Name', 'V5 candidates');
ax = gobjects(1, 6);  hI = gobjects(1, 5);  hT = gobjects(1, 5);
cmapT = jet(256);  cl = [P.T_b, max(cellfun(@(Ok) max(Ok.T(:)), O))];
for k = 1:5
    ax(k) = subplot(2, 3, k);  hold(ax(k), 'on');
    hI(k) = image(ax(k), 'XData', x([1 end]), 'YData', z([1 end]), 'CData', zeros(numel(z), numel(x), 3));
    set(ax(k), 'YDir', 'normal');  axis(ax(k), 'image');
    xlim(ax(k), [-6 20]);  ylim(ax(k), [-14 P.d*1e3 + 1]);
    plot(ax(k), [0 P.L*1e3], P.d*1e3*[1 1], 'k-', 'LineWidth', 2.5);          % antenna
    plot(ax(k), [-6 20], [-1 -1], 'c-', 'LineWidth', 1);                      % 1 mm clear layer
    xlabel(ax(k), 'x (mm)');  ylabel(ax(k), 'z (mm)');
    hT(k) = title(ax(k), names{k}, 'FontSize', 9);
end
ax(6) = subplot(2, 3, 6);  hold(ax(6), 'on');  grid(ax(6), 'on');
for k = 1:5, plot(ax(6), t, M{k}.lesmax_depth, 'LineWidth', 1.6); end
yline(ax(6), 1, 'c-');
hNow = xline(ax(6), 0, 'k:', 'LineWidth', 1.4);
xlabel(ax(6), 'time (s)');  ylabel(ax(6), 'colour depth (mm)');  xlim(ax(6), [0 t(end)]);
legend(ax(6), names, 'Location', 'southeast', 'FontSize', 8);
title(ax(6), 'Colour depth (deepest point ever >= colour start)');
sg = sgtitle(fig, '');
if ~strcmp(o.look, 'pigment')
    colormap(fig, cmapT);  cb = colorbar(ax(3));  cb.Label.String = 'T (degC)';  caxis(ax(3), cl);
end

vw = [];
if o.video
    d = fileparts(o.file);  if ~isempty(d) && ~exist(d, 'dir'), mkdir(d); end
    vw = VideoWriter(o.file, 'MPEG-4');  vw.FrameRate = o.fps;  open(vw);
end
hC = gobjects(1, 5);
for n = 1:o.every:nt
    for k = 1:5
        Tn = double(O{k}.T(:, :, n));
        if strcmp(o.look, 'pigment')
            hI(k).CData = v5_tlc(Tn, P.T_tlc, P.bw_tlc, 'vivid');
        else
            idx = round(1 + 255*min(max((Tn - cl(1))/(cl(2) - cl(1)), 0), 1));
            hI(k).CData = reshape(cmapT(idx, :), [size(Tn) 3]);
        end
        if isgraphics(hC(k)), delete(hC(k)); end
        if max(Tn(:)) >= lim
            [~, hC(k)] = contour(ax(k), x, z, Tn, [lim lim], 'w--', 'LineWidth', 1.2);
        end
        Wnow = Q{k}.P_set*O{k}.env.p_now(n);
        if isinf(M{k}.Dmax_protect(n)), cs = 'no colour yet'; else, cs = sprintf('clear %.2f mm', M{k}.Dmax_protect(n)); end
        hT(k).String = sprintf('%s  |  %4.1f W  |  %s, depth %.1f mm', names{k}, Wnow, cs, M{k}.lesmax_depth(n));
    end
    hNow.Value = t(n);
    sg.String = sprintf('Edward''s setup, %g L/min:  t = %3.0f s  %s', o.flow, t(n), ...
                        tern(t(n) < P.t_on, '(power on)', '(power off: cooling)'));
    drawnow;
    if ~isempty(vw), writeVideo(vw, getframe(fig)); end
    if o.pause > 0, pause(o.pause); end
end
if ~isempty(vw), close(vw); fprintf('video saved: %s\n', o.file); end
end

fprintf('\n%-20s %8s %10s %9s %9s %10s\n', 'candidate', 'mean W', 'sparing', 'depth', 'onset', 'length');
for k = 1:5
    fprintf('%-20s %7.1fW %8.2fmm %7.2fmm %8.0fs %8.1fmm\n', names{k}, S(k).mean_W, S(k).sparing_mm, ...
            S(k).depth_mm, S(k).onset_s, S(k).length_mm);
end
end

function s = tern(c, a, b)
if c, s = a; else, s = b; end
end
