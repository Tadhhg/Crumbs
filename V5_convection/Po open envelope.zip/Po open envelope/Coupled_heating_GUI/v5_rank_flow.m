function [T, best] = v5_rank_flow(varargin)
%V5_RANK_FLOW  Best power envelopes for each circulation flow rate, ranked, with
%              a check against flow fluctuations (the flow is the input the lab
%              controls, and the factor that fluctuates most).
%
%   [T, best] = v5_rank_flow()                          Edward's bench, flows 2..20 L/min
%   [T, best] = v5_rank_flow('flows', [2 5 10], 'P_max', 90, 's_clear', 1, 'wobble', 0.2)
%
%   For every flow f (surface cooling h_s follows the flow, v5_flow_hs) and every
%   candidate power envelope:
%     1. the envelope is scaled as high as it can go (never above P_max) while
%        the top s_clear mm stays below T_limit (pigment colour start by default);
%     2. it is run at the nominal flow: colour depth, onset, mean power;
%     3. the SAME envelope is run at (1 - wobble) f and (1 + wobble) f: does the
%        clear layer survive a low-flow dip, and how much depth is lost?
%   Candidates: constant power, pulsed 80 % / 10 s, pulsed 50 % / 10 s,
%   boost 5 s then constant, the optimal envelope, its 6-step version, and the
%   ROBUST optimal envelope (designed for the low-flow edge, run at nominal).
%
%   T     one row per (flow, candidate): flow_Lmin, h_s, candidate, depth_mm,
%         onset_s, mean_W, peak_W, layer_max_lowflow_C, safe_lowflow (layer max <=
%         T_limit + 0.1 at the low flow), depth_lowflow_mm, depth_highflow_mm, rank_at_flow
%   best  per flow: the best candidate by depth, and the best one that is also safe
%         at the low-flow dip -- the envelope to use
%   Writes v5_envelope/rank_flow.csv and rank_flow.png (depth vs flow per candidate).
%
%   Options: 'preset' 'photo', 'set' struct overrides, 'flows' [2 5 10 15 20],
%   'P_max' 90, 't_on' 360, 's_clear' 1, 'T_limit' [] (= P.T_tlc), 'wobble' 0.2,
%   'hs' {'h_ref', 1400, 'flow_ref', 5, 'exponent', 0.5} (v5_flow_hs options),
%   'outdir' './v5_envelope'.

o = struct('preset', 'photo', 'set', struct(), 'flows', [2 5 10 15 20], 'P_max', 90, 't_on', 360, ...
           's_clear', 1, 'T_limit', [], 'wobble', 0.2, 'hs', {{}}, 'outdir', fullfile(pwd, 'v5_envelope'));
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end
if ~exist(o.outdir, 'dir'), mkdir(o.outdir); end

P0 = v5_defaults(o.preset);
f = fieldnames(o.set);
for i = 1:numel(f), P0.(f{i}) = o.set.(f{i}); end
P0.t_on = o.t_on;  P0.P_set = o.P_max;  P0.duty = 1;  P0.t_rest = 0;  P0.env_t = [];  P0.env_p = [];
if isempty(o.T_limit), o.T_limit = P0.T_tlc; end
lim = o.T_limit - 0.01;

names = {'Constant power', 'Pulsed 80% / 10 s', 'Pulsed 50% / 10 s', 'Boost 5 s, then constant', ...
         'Optimal (boost, then hold)', '6-step optimal', 'Robust optimal (for low-flow dip)'};
rows = [];
for fl = o.flows
    fprintf('flow %g L/min ...\n', fl);
    [R, P, L, lay] = build(fl);
    [Rlo, Plo, Llo, ~] = build(fl*(1 - o.wobble));
    [Rhi, Phi, Lhi, ~] = build(fl*(1 + o.wobble));
    nt = numel(R.t);  tt = R.t(1:end-1);  on = tt < P.t_on;

    Out   = v5_optimise_envelope(R, P, 's_protect', o.s_clear, 'T_protect', o.T_limit, 'T_lesion', o.T_limit, 'verbose', false);
    OutLo = v5_optimise_envelope(Rlo, Plo, 's_protect', o.s_clear, 'T_protect', o.T_limit, 'T_lesion', o.T_limit, 'verbose', false);
    edges = [0 2 6 20 60 150 P.t_on];  st = zeros(1, 6);
    for k = 1:6, st(k) = mean(Out.track.a(tt >= edges(k) & tt < edges(k+1))); end

    shapes = cell(1, numel(names));
    shapes{1} = shapeOf(P, struct());
    shapes{2} = shapeOf(P, struct('duty', 0.8, 'T_pulse', 10));
    shapes{3} = shapeOf(P, struct('duty', 0.5, 'T_pulse', 10));
    shapes{4} = shapeOf(P, struct('env_t', [0 5], 'env_p', [1 0.4]));
    shapes{5} = Out.track.a;
    shapes{6} = shapeOf(P, struct('env_t', edges(1:end-1), 'env_p', st/max(st)));
    shapes{7} = OutLo.track.a;

    for c = 1:numel(names)
        a = shapes{c};
        if c ~= 5 && c ~= 7                       % scale to the limit (5 and 7 are already there)
            G = L.H(lay, :)*toep(a, nt);  T0 = L.T0(lay, :);
            pos = G > 1e-12;
            s = min((lim - T0(pos))./G(pos));
            s = min([s, 1/max(a)]);
            a = max(s, 0)*a;
        end
        [dep, ons] = evalEnv(R, P, L, a);
        [depLo, ~, TlLo] = evalEnv(Rlo, Plo, Llo, a);
        [depHi, ~, ~] = evalEnv(Rhi, Phi, Lhi, a);
        r = struct('flow_Lmin', fl, 'h_s', P.h_s, 'candidate', names{c}, 'depth_mm', dep, 'onset_s', ons, ...
                   'mean_W', o.P_max*sum(a(on))*L.dt/P.t_on, 'peak_W', o.P_max*max(a), ...
                   'layer_max_lowflow_C', TlLo, 'safe_lowflow', double(TlLo <= o.T_limit + 0.1), ...
                   'depth_lowflow_mm', depLo, 'depth_highflow_mm', depHi, 'rank_at_flow', NaN);
        rows = [rows r]; %#ok<AGROW>
    end
    k = find([rows.flow_Lmin] == fl);
    [~, ord] = sort([rows(k).depth_mm], 'descend');
    for j = 1:numel(ord), rows(k(ord(j))).rank_at_flow = j; end
end

% ------------------------------------------------------------- report ---
T = rows;
fid = fopen(fullfile(o.outdir, 'rank_flow.csv'), 'w');
fn = fieldnames(rows);  fprintf(fid, '%s\n', strjoin(fn.', ','));
for i = 1:numel(rows)
    v = cellfun(@(f) rows(i).(f), fn, 'UniformOutput', false);
    s = cellfun(@csvCell, v, 'UniformOutput', false);
    fprintf(fid, '%s\n', strjoin(s.', ','));
end
fclose(fid);

best = struct('flow_Lmin', {}, 'best', {}, 'best_depth_mm', {}, 'best_safe', {}, 'safe_depth_mm', {});
fprintf('\n%-6s %-34s %8s %8s %9s %10s %9s\n', 'flow', 'candidate (ranked by depth)', 'depth', 'onset', 'mean W', 'low-flow', 'depth@lo');
for fl = o.flows
    k = find([rows.flow_Lmin] == fl);
    [~, ord] = sort([rows(k).depth_mm], 'descend');
    for j = ord
        r = rows(k(j));
        fprintf('%-6g %-34s %6.2fmm %6.0fs %8.1fW %10s %7.2fmm\n', fl, r.candidate, r.depth_mm, r.onset_s, r.mean_W, ...
                tern(r.safe_lowflow, 'safe', sprintf('%.1fC!', r.layer_max_lowflow_C)), r.depth_lowflow_mm);
    end
    kk = k(ord);  safe = kk([rows(kk).safe_lowflow] == 1);
    b = struct('flow_Lmin', fl, 'best', rows(kk(1)).candidate, 'best_depth_mm', rows(kk(1)).depth_mm, ...
               'best_safe', '', 'safe_depth_mm', NaN);
    if ~isempty(safe), b.best_safe = rows(safe(1)).candidate;  b.safe_depth_mm = rows(safe(1)).depth_mm; end
    best(end+1) = b; %#ok<AGROW>
    fprintf('  -> best at %g L/min: %s (%.2f mm); best that survives a %d%% flow dip: %s (%.2f mm)\n\n', ...
            fl, b.best, b.best_depth_mm, round(100*o.wobble), b.best_safe, b.safe_depth_mm);
end

fig = figure('Visible', 'off', 'Color', 'w', 'Position', [80 80 900 500]);  hold on;  grid on;
for c = 1:numel(names)
    k = strcmp({rows.candidate}, names{c});
    plot([rows(k).flow_Lmin], [rows(k).depth_mm], '-o', 'LineWidth', 1.5);
end
xlabel('circulation flow (L/min)');  ylabel(sprintf('colour depth (mm), top %.1f mm kept clear', o.s_clear));
legend(names, 'Location', 'southeast');  title('Best envelope per flow rate (V5, h_s follows flow)');
print(fig, fullfile(o.outdir, 'rank_flow.png'), '-dpng', '-r120');  close(fig);

% =========================================================================
    function [R, P, L, lay] = build(fl)
        P = P0;  P.flow = fl;  P = v5_flow_hs(P, o.hs{:});
        R = v5_solve(P);
        L = v5_linear(R, P);
        depth = -R.z(:)*1e3;
        [ZZ, ~] = ndgrid(1:numel(R.z), 1:numel(R.x));
        lay = find(depth(ZZ) <= o.s_clear + 1e-9);
    end

    function a = shapeOf(P, s)
        Q = P;  fs = fieldnames(s);
        for q = 1:numel(fs), Q.(fs{q}) = s.(fs{q}); end
        E = v5_envelope(Q, R.t);  a = E.pbar;
    end

    function [dep, ons, Tlay] = evalEnv(Rr, Pr, Lr, a)
        Tm = Lr.apply(a);
        O = struct('T', reshape(single(Tm), Lr.nz, Lr.nx, numel(Rr.t)));
        M = v5_metrics(Rr, O, Pr, struct('T_protect', o.T_limit, 'T_lesion', o.T_limit, 'T_colour', o.T_limit));
        dep = M.lesmax_depth(end);
        k1 = find(M.lesmax_depth > o.s_clear, 1);
        if isempty(k1), ons = NaN; else, ons = Rr.t(k1); end
        Tlay = max(max(Tm(lay, :)));
    end
end

function M = toep(a, nt)
a = a(:).';  M = zeros(nt - 1, nt);
for n = 2:nt, M(1:n-1, n) = a(n-1:-1:1); end
end

function s = csvCell(x)
if ischar(x), s = ['"' x '"']; else, s = sprintf('%.6g', x); end
end

function s = tern(c, a, b)
if c, s = a; else, s = b; end
end
