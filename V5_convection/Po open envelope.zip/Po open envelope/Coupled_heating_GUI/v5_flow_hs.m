function P = v5_flow_hs(P, varargin)
%V5_FLOW_HS  Make the water-to-gel surface coefficient h_s follow the flow rate.
%
%   P = v5_flow_hs(P)                         h_s = 1400 * (flow/5)^0.5
%   P = v5_flow_hs(P, 'h_ref', 1400, 'flow_ref', 5, 'exponent', 0.5)
%
%   In the team's V5, h_s is fixed and the flow only changes the catheter-water
%   term alpha.  Physically the surface cooling grows with the water speed over
%   the gel: laminar flat plate Nu = 0.664 Re^0.5 Pr^(1/3), so h ~ flow^0.5
%   (V4 used this: ~1400 W/m2K at 5 L/min).  Use exponent 0.8 for turbulent flow.
%   h_ref / flow_ref should be refitted to the bench (v5_bench) when possible.
%
%   Call it after setting P.flow and before v5_solve (h_s is a solve field, so a
%   new flow now needs a new solve, ~3 s).  The GUI does not call this: its flow
%   slider still changes alpha only.

o = struct('h_ref', 1400, 'flow_ref', 5, 'exponent', 0.5);
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end
P.h_s = o.h_ref*(max(P.flow, 1e-6)/o.flow_ref)^o.exponent;
end
