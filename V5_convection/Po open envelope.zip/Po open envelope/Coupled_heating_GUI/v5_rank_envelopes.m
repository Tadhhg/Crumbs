function T = v5_rank_envelopes(varargin)
%V5_RANK_ENVELOPES  Rank candidate power envelopes on a fair footing.
%
%   T = v5_rank_envelopes()                       Edward's bench (photo preset), 90 W max, 6 min
%   T = v5_rank_envelopes('s_clear', 1, 'T_limit', 40.5, 'P_max', 90, 'set', struct('h_s', Inf))
%
%   Each candidate is a SHAPE (on/off pulses, ramps, steps ...).  Its power is
%   scaled up as far as it can go (never above P_max at any instant) while the
%   top s_clear mm of gel never reaches T_limit (default: the pigment colour
%   start P.T_tlc, i.e. the clear top layer stays clear).  Then every candidate
%   has the same safety and the same power limit, and they are ranked by how
%   deep the colour (T >= T_limit) reaches -- the bench's "depth".
%
%   Output table columns: rank, name, P_scale_W (the P_set it was scaled to),
%   mean_W, energy_J, depth_mm (colour depth, ever), length_mm (colour length at
%   t_on), onset_s (first colour below the clear layer), spared_mm (clear layer
%   actually kept; >= s_clear), and a PNG of all envelopes (v5_envelope/rank.png).
%
%   Options: 'preset' ('photo'), 'set' (struct of overrides, e.g. h_s), 'P_max' (90 W),
%   't_on' (360 s), 's_clear' (1 mm), 'T_limit' ([] = P.T_tlc), 'plot' (true),
%   'outdir' ('./v5_envelope').

o = struct('preset', 'photo', 'set', struct(), 'P_max', 90, 't_on', 360, 's_clear', 1, ...
           'T_limit', [], 'plot', true, 'outdir', fullfile(pwd, 'v5_envelope'));
for i = 1:2:numel(varargin), o.(varargin{i}) = varargin{i+1}; end
P = v5_defaults(o.preset);
f = fieldnames(o.set);
for i = 1:numel(f), P.(f{i}) = o.set.(f{i}); end
P.t_on = o.t_on;  P.P_set = o.P_max;
if isempty(o.T_limit), o.T_limit = P.T_tlc; end
R = v5_solve(P);
depth = -R.z(:)*1e3;  lay = depth <= o.s_clear + 1e-9;
ton = P.t_on;

% ---------------------------------------------------------- candidates ---
% name, then fields set on P (env_p is the SHAPE, 0..1; the scale is P_set)
C = {
 'Constant power (CW)',                 struct();
 'Pulsed 80% duty, 10 s period',        struct('duty', 0.8, 'T_pulse', 10);
 'Pulsed 50% duty, 10 s period',        struct('duty', 0.5, 'T_pulse', 10);
 'Pulsed 50% duty, 30 s period',        struct('duty', 0.5, 'T_pulse', 30);
 'Bursts 60 s on / 20 s rest',          struct('t_burst', 60, 't_rest', 20);
 'Ramp up (0 to max)',                  struct('env_t', 0:10:ton-10, 'env_p', linspace(0.05, 1, numel(0:10:ton-10)));
 'Ramp down (max to 0)',                struct('env_t', 0:10:ton-10, 'env_p', linspace(1, 0.05, numel(0:10:ton-10)));
 'Boost 20 s, then constant',           struct('env_t', [0 20], 'env_p', [1 0.4]);
 'Boost 5 s, then constant',            struct('env_t', [0 5], 'env_p', [1 0.4]);
};
% the optimum, and its 6-step simplification, from v5_optimise_envelope
Out = v5_optimise_envelope(R, P, 's_protect', o.s_clear, 'T_protect', o.T_limit, ...
                           'T_lesion', o.T_limit, 'verbose', false);
edges = [0 2 6 20 60 150 ton];
tt = R.t(1:end-1);  a = Out.track.a;
st = zeros(1, numel(edges) - 1);
for k = 1:numel(st), st(k) = mean(a(tt >= edges(k) & tt < edges(k+1))); end
C(end+1, :) = {'6-step version of the optimum', struct('env_t', edges(1:end-1), 'env_p', st/max(st))};
C(end+1, :) = {'Optimal (boost, then hold)',   struct('env_t', tt, 'env_p', a/max(a))};

% ------------------------------------------------------------ evaluate ---
n = size(C, 1);
rows = struct('name', {}, 'P_scale_W', {}, 'mean_W', {}, 'energy_J', {}, 'depth_mm', {}, ...
              'length_mm', {}, 'onset_s', {}, 'spared_mm', {});
env = cell(n, 1);
for k = 1:n
    Q = P;  s = C{k, 2};  fs = fieldnames(s);
    for i = 1:numel(fs), Q.(fs{i}) = s.(fs{i}); end
    lo = 0;  hi = o.P_max;                        % largest P_set that keeps the layer clear
    if ok(hi), lo = hi; else
        for it = 1:30
            m = (lo + hi)/2;
            if ok(m), lo = m; else, hi = m; end
        end
    end
    Q.P_set = lo;
    O = v5_eval(R, Q);
    M = v5_metrics(R, O, Q, struct('T_protect', o.T_limit, 'T_lesion', o.T_limit, 'T_colour', o.T_limit));
    nOn = find(R.t <= ton, 1, 'last');
    k1 = find(M.lesmax_depth > o.s_clear, 1);
    rows(k) = struct('name', C{k, 1}, 'P_scale_W', lo, 'mean_W', O.P_del/(1 - Q.P_dropoff)*O.env.mean_on, ...
                     'energy_J', lo*O.env.mean_on*ton, 'depth_mm', M.lesmax_depth(end), ...
                     'length_mm', M.col_length(nOn), 'onset_s', ifempty(R.t(k1), NaN), ...
                     'spared_mm', min(M.Dmax_protect(end), 99));
    env{k} = [O.env.ts(:) lo*O.env.ps(:)];
    fprintf('%-32s scaled to %5.1f W: colour depth %5.2f mm, onset %4.0f s\n', C{k, 1}, lo, rows(k).depth_mm, rows(k).onset_s);
end

[~, ord] = sort([rows.depth_mm], 'descend');
rows = rows(ord);  env = env(ord);
for k = 1:n, rows(k).rank = k; end
T = struct2table(rows);
T = T(:, {'rank', 'name', 'depth_mm', 'onset_s', 'length_mm', 'spared_mm', 'mean_W', 'energy_J', 'P_scale_W'});
fprintf('\nRanking: top %.1f mm kept below %.1f degC, max %g W, %g s (preset %s)\n', o.s_clear, o.T_limit, o.P_max, ton, o.preset);
disp(T);
if o.plot
    if ~exist(o.outdir, 'dir'), mkdir(o.outdir); end
    fig = figure('Color', 'w', 'Position', [80 80 1000 520], 'Visible', 'off');
    hold on;  grid on;
    for k = 1:n, stairs(env{k}(:, 1), env{k}(:, 2), 'LineWidth', 1.3); end
    xlim([0 ton + 20]);  xlabel('time (s)');  ylabel('generator power (W)');
    legend(strcat(string(1:n).', '. ', string({rows.name}.')), 'Location', 'eastoutside');
    title(sprintf('Candidates ranked by colour depth (top %.1f mm kept < %.1f C)', o.s_clear, o.T_limit));
    print(fig, fullfile(o.outdir, 'rank.png'), '-dpng', '-r120');  close(fig);
end

    function tf = ok(Pw)
        Qt = Q;  Qt.P_set = Pw;
        Ot = v5_eval(R, Qt);
        Tl = Ot.T(lay, :, :);
        tf = max(Tl(:)) < o.T_limit - 0.01;
    end
end

function v = ifempty(x, d)
if isempty(x), v = d; else, v = x; end
end
