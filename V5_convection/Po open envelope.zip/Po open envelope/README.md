# Po_open_envelope: power-envelope optimisation for the V5 gel model

Tools that sit **on top of** the team's V5 model (`../Coupled_heating_GUI`, Team 7, V5 by Tadhg Stuckey).
They find, rank and simulate generator power envelopes that heat as deep and as fast as possible while
keeping a clear surface layer. None of the team's files are changed. Added by Po-An Chien, 29 Sep 2026.

## How to use it (step by step)

1. **Get the latest repo:** `git pull`. You need both `V5_convection/Coupled_heating_GUI` (the team model) and `V5_convection/Po_open_envelope` (this folder).
2. **Open MATLAB and go to this folder:**
   ```matlab
   cd('<your path>/V5_convection/Po_open_envelope')
   setup_open_envelope        % once per MATLAB session; prints where the model and tools are
   ```
3. **Check it works:**
   ```matlab
   v5_selftest_extra          % ~1 min, should end with ALL PASS
   ```
4. **See the 5 candidates side by side (and record a video):**
   ```matlab
   S = v5_compare_candidates('look', 'pigment', 'video', true);   % saves v5_envelope/candidates.mp4
   ```
   Keep the figure window open and on screen until it prints "video saved" and the scorecard.
5. **Rank envelopes for different flow rates:**
   ```matlab
   [T, best] = v5_rank_flow('flows', [3 4 5 6 7], 'outdir', 'my_flow_run');
   ```
   It prints a ranked table per flow and writes `my_flow_run/rank_flow.csv` and `rank_flow.png`.
6. **Get the best envelope for your own conditions** (e.g. 4 L/min, 60 W max):
   ```matlab
   P = v5_defaults('photo');  P.P_set = 60;  P.flow = 4;  P = v5_flow_hs(P);
   R = v5_solve(P);
   Out = v5_optimise_envelope(R, P, 's_protect', 1, 'T_protect', P.T_tlc, 'T_lesion', P.T_tlc);
   plot(Out.track.env_t, P.P_set*Out.track.env_p); xlabel('time (s)'); ylabel('generator W')
   ```
7. **Load an envelope into the team GUI:**
   ```matlab
   fig = v5_gui('photo');  u = fig.UserData;
   u.setParam('P_set', P.P_set);  u.setParam('env_p', []);
   u.setParam('env_t', Out.track.env_t);  u.setParam('env_p', Out.track.env_p);
   ```

Tips: run each study with its own `'outdir'` so results don't overwrite each other. Everything runs offline.
More detail: `docs/HOW_TO_TEST_ENVELOPE.md` (test plan) and `docs/V5_UPDATE_NOTES.md` (V4 vs V5 vs bench).

## Headline (Edward's bench: 12 mm antenna, 1.1 mm, 25 °C bath, 6 min, top 1 mm kept clear)

| # | Candidate | Generator setting | Clear layer | Colour depth | Colour appears |
|---|---|---|---|---|---|
| 1 | Robust optimal | 90 W for 2 s, easing to ~25 W (designed for a 20 % flow dip) | 1.17 mm | 6.5 mm | 34 s |
| 2 | 6-step | 83.5 → 57 → 40.5 → 30.5 → 26 → 24.5 W at 0/2/6/20/60/150 s | 1.24 mm | 6.2 mm | 48 s |
| 3 | Constant | 25 W | 1.23 mm | 6.1 mm | 128 s |
| 4 | Short boost | 62 W for 5 s, then 25 W | 1.22 mm | 6.2 mm | 120 s |
| 5 | Pulsed | 29.7 W, 80 % duty, 10 s period | 1.26 mm | 5.6 mm | 148 s |

- Boost-then-hold is the best shape (proven optimal in V5); pulsing is always last (matches Edward's data).
- Flow is the biggest lever: about +0.3 mm colour depth per extra L/min. Only the robust envelope keeps the clear layer when flow dips.
- The ranking held across pigment temperature, 60 vs 90 W, finer grid, turbulent cooling and ±30 % flow wobble (`results/rank_flow_all_tests.csv`).
- **Model predictions, not yet bench-validated.** Still needed: the pigment colour-change temperature, the real flow wobble, and colour depth at 2–3 flows.

## Files

| File | What it does |
|---|---|
| `setup_open_envelope.m` | adds the team model + these tools to the path |
| `v5_envelope.m`, `v5_defaults.m` | team versions + optional custom power shape (`P.env_t`, `P.env_p`) |
| `v5_flow_hs.m` | surface cooling h_s follows flow (h ∝ flow^0.5, 1400 W/m²K at 5 L/min) |
| `v5_optimise_envelope.m` | optimal envelope for a clear-layer limit (boost, then hold) vs best constant power |
| `v5_max_sparing.m` | thickest clear layer for a required lesion/colour depth |
| `v5_rank_envelopes.m`, `v5_rank_flow.m` | rank candidate envelopes (fixed flow / per flow, with flow-dip check) |
| `v5_compare_candidates.m` | animate the 5 candidates side by side, save MP4, print scorecard |
| `v5_pid.m` | PID controller simulation |
| `v5_metrics.m`, `v5_linear.m` | sparing/lesion/colour metrics; fast exact linear map of V5 |
| `v5_run_case.m`, `v5_envelope_study.m` | headless sweeps with full CSV logging |
| `v5_bench.m`, `bench/` | compare V5 with Edward's bench sheet (25 Aug) |
| `v5_selftest_extra.m` | checks of all the above |
| `docs/` | update notes, test instructions, figures |
| `results/` | study and ranking CSVs, robust-envelope figure |
