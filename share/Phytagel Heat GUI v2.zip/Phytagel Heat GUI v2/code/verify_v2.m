function verify_v2()
%VERIFY_V2  Checks on the bath-above-the-gel change, before any result from it
%           is believed.
%
%   1  tangential E is continuous across z = 0   -- pins the TM sign S_TM
%   2  'air' above reproduces v1 EXACTLY         -- nothing else moved
%   3  the cut height Zw does not matter         -- the construction as a whole
%   4  the power budget closes                   -- fractions sum to 1
%   5  uniform medium, wire on z = 0, is up/down symmetric
%
%   Test 5 is the only one that puts the NEW bath field expressions and the
%   OLD gel ones on the same footing, so it is the one that would catch an
%   error the continuity test at a single plane could miss.

here = fileparts(mfilename('fullpath'));
addpath(fullfile(here,'matlab'), fullfile(here,'Heatmodel','matlab'));
v1 = fileparts(here);
fprintf('\n================ verify_v2 ================\n');
pass = true;

C  = model_config('Pdel',1,'upper','water','bath_NaCl_pct',0.9,'T_bath_C',25);
zn = -(0:0.5e-3:30e-3).';
base = {'f',C.f,'d',C.d,'h',C.h,'L',C.L,'ke',C.ke,'Idist',C.Idist, ...
        'Nfft',512,'dx',C.dx,'Pdel',1,'zn',zn, ...
        'xlim',[-10e-3 30e-3],'ylim',[-10e-3 10e-3],'Zw',C.Zw,'dzw',C.dzw};
wet = [C.epsr_upper, C.epsr_gel, C.epsr_air];

% ---- 1. interface continuity --------------------------------------------
cfg = struct(base{:}, 'epsr',wet, 'debug_interface',true);
s = sar_volume(cfg);  D = s.dbg;
for nm = {'Ex','Ey'}
    b = D.([nm{1} '_bath']);  g = D.([nm{1} '_gel']);
    e = norm(b(:)-g(:))/norm(g(:));
    ok = e < 1e-12;  pass = pass && ok;
    fprintf('  1  tangential %s continuous at z=0 : rel err %8.2e  %s\n', nm{1}, e, tick(ok));
end

% ---- 2. air above must reproduce v1 -------------------------------------
cfg_air = struct(base{:}, 'epsr',[C.epsr_air, C.epsr_gel, C.epsr_air]);
s_air = sar_volume(cfg_air);
old = fullfile(v1,'Heatmodel','matlab');
have_v1 = exist(fullfile(old,'sar_volume.m'),'file') == 2;
if ~have_v1
    % The shared package ships v2 on its own.  Do NOT fall through to the
    % comparison here: addpath on a missing folder only WARNS, so sar_volume
    % would resolve to v2's own copy and this test would compare v2 against
    % itself and pass vacuously.  Say it was skipped instead.
    disp('  2  v1 is not beside this copy -- comparison skipped, not run');
    disp('     (at build time: Pgel, Pup, Pdn and the whole deposition');
    disp('      map identical to machine precision)');
else
addpath(old,'-begin');                                  % v1 solver wins
s_v1 = sar_volume(rmfield(cfg_air,{'Zw','dzw'}));
rmpath(old);
for f = {'Pgel','Pup','Pdn'}
    a = s_air.(f{1});  b = s_v1.(f{1});
    e = abs(a-b)/max(abs(b), s_v1.Pgel);
    ok = e < 1e-12;  pass = pass && ok;
    fprintf('  2  air above %-5s v2 %.7e  v1 %.7e  rel %7.1e  %s\n', f{1},a,b,e,tick(ok));
end
dq = max(abs(s_air.q(:)-s_v1.q(:)))/max(abs(s_v1.q(:)));
ok = isequal(size(s_air.q),size(s_v1.q)) && dq < 1e-12;  pass = pass && ok;
fprintf('  2  air above, deposition map identical      max rel %7.1e  %s\n', dq, tick(ok));
end
ok = s_air.Pwat == 0;  pass = pass && ok;
fprintf('  2  air above, bath absorbs exactly zero                     %s\n', tick(ok));

% ---- 3. the cut height must not matter ----------------------------------
% What leaves the top of the integrated column is counted as Pup instead of
% Pwat, so where the column is cut must not change what reaches the gel.
fprintf('  3  Zw independence:\n');
g0 = [];
for Zw = [20e-3 40e-3 80e-3]
    c = struct(base{:}, 'epsr',wet);  c.Zw = Zw;
    z = sar_volume(c);  T = z.Pgel+z.Pwat+z.Pup+z.Pdn;
    fr = z.Pgel/T;
    if isempty(g0), g0 = fr; end
    e = abs(fr-g0)/g0;  ok = e < 2e-3;  pass = pass && ok;
    fprintf('     Zw=%2.0f mm  gel %.4f  bath %.4f  escaping %.2e   drift %6.1e  %s\n', ...
            1e3*Zw, fr, z.Pwat/T, z.Pup/T, e, tick(ok));
end

% ---- 4. budget closes ----------------------------------------------------
T = s.Pgel+s.Pwat+s.Pup+s.Pdn;
fr = [s.Pgel s.Pwat s.Pup s.Pdn]/T;
ok = abs(sum(fr)-1) < 1e-12;  pass = pass && ok;
fprintf('  4  fractions sum to 1                                       %s\n', tick(ok));
fprintf('     saline bath: gel %.1f%%  bath %.1f%%  up %.2f%%  down %.2f%%\n', 100*fr);

% ---- 5. uniform medium, wire ON the plane -------------------------------
% All three layers the same and h = 0: the half-spaces are mirror images, so
% the power absorbed above must equal that below.
%   An earlier version of this test left the wire at h = 0.5 mm and expected
%   a ratio near 1.  That expectation was wrong, not the code -- at h > 0 the
%   wire's own near field sits inside the UPPER region, so that side
%   legitimately dominates (it came out 16x).  Putting the source on the
%   interface is what makes the two sides comparable.
cfg_h = struct(base{:}, 'epsr',[C.epsr_gel C.epsr_gel C.epsr_gel]);
cfg_h.h = 0;  cfg_h.Zw = 30e-3;  cfg_h.dzw = 0.5e-3;
sh = sar_volume(cfg_h);
r = sh.Pwat/sh.Pgel;  e = abs(r-1);  ok = e < 5e-3;  pass = pass && ok;
fprintf('  5  uniform medium, wire on z=0: above/below = %.6f          %s\n', r, tick(ok));

fprintf('\n  %s\n\n', pick(pass,'ALL CHECKS PASSED','SOMETHING FAILED'));
end
function s = tick(ok),   if ok, s='ok'; else, s='FAIL'; end, end
function s = pick(c,a,b), if c, s=a; else, s=b; end, end
