function run_v2_comparison()
%RUN_V2_COMPARISON  v1 (air above) vs v2 (bath above) for the bench run that
%                   was photographed: 50 W CW, 6 minutes, everything at 25 C.
here = fileparts(mfilename('fullpath'));
addpath(fullfile(here,'matlab'), fullfile(here,'Heatmodel','matlab'));

b = {'T_gel',25,'T_water',25,'Pgen',50,'t_stim',360, ...
     'surf_bc','robin','cath_bc','cooled'};
fprintf('\n=========== 50 W CW, 360 s, gel and bath at 25 C ===========\n\n');

R = struct();
R.v1  = gui_model(b{:}, 'upper','air');
R.di  = gui_model(b{:}, 'upper','water', 'bath_NaCl_pct',0);
R.sal = gui_model(b{:}, 'upper','water', 'bath_NaCl_pct',0.9);
nm = {'v1  air above (the old model)','v2  deionised/tap bath','v2  0.9% saline bath'};
fn = {'v1','di','sal'};

fprintf('%-30s %8s %8s %8s %9s %9s\n', ...
        '', 'gel %', 'bath %', 'Pgel W', 'peak C', 'probe C');
for k = 1:3
    i = R.(fn{k}).info;
    fprintf('%-30s %8.1f %8.1f %8.2f %9.1f %9.1f\n', nm{k}, ...
            100*i.frac_gel, 100*i.frac_bath, i.Pgel, i.T_end, i.T_probe_end);
end

fprintf('\n  bath permittivity used:\n');
for k = 2:3
    e = R.(fn{k}).info.epsr_upper;
    fprintf('    %-26s eps'' %6.2f   sigma %.3f S/m\n', nm{k}, ...
            real(e), -imag(e)*2*pi*2.45e9*8.8541878128e-12);
end

fprintf('\n  time for the peak to cross a threshold:\n');
fprintf('    %-28s %8s %8s %8s\n','','43 C','60 C','100 C');
for k = 1:3
    r = R.(fn{k});  s = sprintf('    %-28s', nm{k});
    for lev = [43 60 100]
        j = find(r.T_max >= lev, 1);
        if isempty(j), s = [s sprintf(' %8s','never')];
        else,          s = [s sprintf(' %8.2f', r.t(j))]; end
    end
    fprintf('%s\n', s);
end

fprintf('\n  ---- against the photographs ----\n');
fprintf('  observed: colour first visible between t=0 and t=29 s; gel intact,\n');
fprintf('            no boiling, no bubbles; coloured core ~9.5 x 6.3 mm at 332 s.\n\n');
for k = 1:3
    i = R.(fn{k}).info;
    fprintf('  %-28s predicts peak %6.1f C  -> %s\n', nm{k}, i.T_end, ...
            verdict(i.T_end));
end

% how much power the bench behaviour implies actually reached the gel
d = R.sal.info.T_probe_end - 25;
fprintf('\n  v2 saline: %.2f K at the probe per generator watt.\n', d/50);
fprintf('  A measured probe rise of 10-25 K would imply %.1f-%.1f W into the gel.\n', ...
        10/(d/50), 25/(d/50));
fprintf('\nDONE\n');
end

function s = verdict(T)
if     T >= 100, s = 'boils -- ruled out by the photos';
elseif T >= 60,  s = 'still far hotter than the gel looks';
else,            s = 'physically plausible';
end
end
