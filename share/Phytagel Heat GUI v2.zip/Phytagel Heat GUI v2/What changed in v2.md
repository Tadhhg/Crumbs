# v2 — the antenna is in the bath, not in air

Self-contained copy of the model with **one physics change**: the medium above the gel.
`../` (v1) is untouched.

## Why

v1 solved a three-layer stack whose top layer was **air** — `layered_field.m` header,
`layer 0 : z > 0 air (source: x-directed wire at z = h)`, with `epsr_air = 1 - 0j`. Against the
gel's ε′ = 74.3 that is an enormous contrast, and it is what drove **99.6 % of the delivered power
into the gel**.

The photographs of the 50 W / 6 min run (`../50W CW 6 min/`) show the antenna **fully immersed**.
Layer 0 is a liquid whose permittivity is close to the gel's own, so the interface nearly
disappears electrically and a large share of the power goes **up into the bath** instead.

## What changed

| file | change |
|---|---|
| `matlab/bath_medium.m` | **new** — bath permittivity, same Stogryn model as the gel |
| `matlab/bath_spectral_E.m` | **new** — spectral E in the bath, above and below the wire |
| `matlab/model_config.m` | `upper` (`'water'`/`'air'`), `bath_NaCl_pct`, `T_bath_C`, `Zw`, `dzw`; resolves `epsr_upper` after overrides |
| `matlab/layered_field.m` | bath absorption in the power budget |
| `Heatmodel/matlab/sar_volume.m` | bath absorption in the power budget; interface self-check |
| `Heatmodel/matlab/gui_model.m` | passes the bath through; reports `frac_bath`, `Pwat`, `epsr_upper` |

### The part that is easy to get wrong

Changing `epsr(1)` alone is **not** enough, and would have made the answer worse rather than better.
v1 normalises by `scale = sqrt(Pdel/Ptot)` with `Ptot = Pgel + Pup + Pdn`. With a *lossless* upper
half-space that is complete: every plane above the source carries the same real flux. With a
*lossy* bath it is not — the bath absorbs, so the flux depends on which plane you measure it on,
and the absorbed power is missing from `Ptot`. Dividing by too small a total would have **inflated**
the field in the gel.

So v2 integrates the dissipation over a bath column `0 ≤ z ≤ Zw` exactly as `Pgel` is integrated
over the slab, and takes `Pup` as the **residual** flux leaving the top of that column. Nothing is
double counted, and the budget closes for any `Zw` — verified below. The bath integral is done in
the spectral domain (Parseval), so it costs no extra FFTs.

## Verification — `verify_v2`

| # | check | result |
|---|---|---|
| 1 | tangential **E** continuous across z = 0 | rel err **1.6e-17** |
| 2 | `upper='air'` reproduces v1 | `Pgel`, `Pup`, `Pdn` and the whole deposition map **identical to machine precision**; bath absorbs exactly 0 |
| 3 | cut height `Zw` does not matter | gel share 0.3917 at Zw = 20/40/80 mm, drift **5e-8**, while bath and escaping flux trade off |
| 4 | budget closes, fractions sum to 1 | exact |
| 5 | uniform medium, wire **on** z = 0, up/down symmetric | **1.000000** |

Test 1 was written before the sign was known and **failed** at first (~1 %), which is what caught it.
Continuity forces `Z0tm*(1-r01b) == Z1tm*(1+r01b)`; substituting `r01b` makes both sides
`2*Z0tm*Z1tm/(Z0tm+Z1tm)` identically, so `S_TM = +1`. Test 5's first version was also wrong — it
left the wire at h = 0.5 mm and expected symmetry, but the wire's near field then lies inside the
upper region (ratio came out 16×). Moving the source onto the interface is what makes the two
sides comparable. **The expectation was wrong, not the code.**

## Result — the photographed run (50 W CW, 360 s, everything at 25 °C)

| | gel % | bath % | P into gel | peak | probe |
|---|---|---|---|---|---|
| v1, air above | 99.6 | 0.0 | 37.4 W | 475 °C | 316 °C |
| v2, deionised/tap bath | 46.4 | 51.3 | 17.4 W | 185 °C | 162 °C |
| v2, 0.9 % saline bath | 39.2 | 60.7 | 14.7 W | 171 °C | 148 °C |

The bath salinity is **not known**, so both ends are run. It matters less than expected: pure water
is already lossy at 2.45 GHz through dipolar relaxation (σ_eff = 1.23 S/m against saline's 2.72),
so the bracket is narrow and the conclusion is robust to not knowing it.

The **shape** barely moves — d50 1.21 → 1.11 mm, d90 7.10 → 6.08 mm, peak still pinned to the feed
exclusion boundary. The bath is essentially a **scalar** on the deposition, which is consistent with
the photographs, where the heated zone's position and proportions looked right and only its
magnitude did not.

## What v2 does NOT fix

**It closes about 2.8× of the gap and no more.** 171 °C still boils, and the photographs show an
intact gel. The remaining factor of 3–6 must come from the causes v2 does not touch:

1. **η = 0.75 is nameplate, not measured** — `Pdel = Pfwd - Pref` = 200 − 50 W, the generator's
   maximum ratings. An unmatched bare wire immersed in water will reflect far more than 25 %.
   **Measure forward and reflected power.** This is still the highest-value measurement.
2. **Current on the coax braid**, which is bare and immersed. Not modelled.
3. **`ke_case = 'quarterwave'`** assumes the element is resonant, which maximises the current.
   `model_config` itself calls this the single largest modelling uncertainty.
4. **Standoff** — v1 and v2 both use h = 0.5 mm with a 0.45 mm conductor; the photos show a clear
   gap and a thicker wire.

## Running it

```matlab
cd v2_water_above
verify_v2                     % the five checks above, ~2 min
run_v2_comparison             % the table above
heat_gui                      % the GUI, now on a water bath by default
gui_model('upper','air', ...) % fall back to v1 behaviour for comparison
```
